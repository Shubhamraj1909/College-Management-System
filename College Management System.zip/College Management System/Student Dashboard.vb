﻿Public Class Student_Dashboard
    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs)
        Application.Exit()
    End Sub

    Private Sub GunaCirclePictureBox6_Click(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub

    Private Sub GunaCirclePictureBox7_Click(sender As Object, e As EventArgs) Handles GunaCirclePictureBox7.Click
        Application.Exit()
    End Sub

    Private Sub GunaCirclePictureBox4_Click(sender As Object, e As EventArgs)
        Dim Obj = New Enquiry()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)
        Dim Obj = New Enquiry()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Student_Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GunaCirclePictureBox2_Click(sender As Object, e As EventArgs)

        'Me.Hide( Dim Obj = New Admission()
        'Obj.Show())
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)
        Dim Obj = New Admission()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub GunaCirclePictureBox1_Click(sender As Object, e As EventArgs)
        Dim Obj = New Courses()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)
        Dim Obj = New Courses()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub GunaCirclePictureBox3_Click(sender As Object, e As EventArgs)
        Dim Obj = New Faculty()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs)
        Dim Obj = New Faculty()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Panel12_Paint(sender As Object, e As PaintEventArgs)

        'Login.Show()
        'Me.Hide()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuImageButton8_Click(sender As Object, e As EventArgs) Handles BunifuImageButton8.Click
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuImageButton5_Click(sender As Object, e As EventArgs) Handles BunifuImageButton5.Click
        Dim Obj = New Faculty()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuImageButton3_Click(sender As Object, e As EventArgs) Handles BunifuImageButton3.Click
        Dim Obj = New Courses()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuImageButton1_Click(sender As Object, e As EventArgs) Handles BunifuImageButton1.Click
        Dim Obj = New Enquiry()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuImageButton4_Click(sender As Object, e As EventArgs) Handles BunifuImageButton4.Click
        Dim Obj = New Admission()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuImageButton7_Click(sender As Object, e As EventArgs) Handles BunifuImageButton7.Click
        Dim Obj = New Events_Show()
        Obj.Show()
        Me.Hide()
    End Sub
End Class