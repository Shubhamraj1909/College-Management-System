﻿Imports System.Data.SqlClient
Public Class Students
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")

    Private Sub FillDepartment()
        Con.Open()
        Dim query = "select * from DepartmentsTbl"
        Dim cmd As New SqlCommand(query, Con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim Tbl As New DataTable()
        adapter.Fill(Tbl)
        DepartmentsCb.DataSource = Tbl
        DepartmentsCb.DisplayMember = "DeptName"
        DepartmentsCb.ValueMember = "DeptName"
        Con.Close()
    End Sub

    Private Sub DisplayStudents()
        Con.Open()
        Dim query = "select * from StudentsTbl"
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        StudentsDGV.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub NoDueList()
        Con.Open()
        Dim query = "select * from StudentsTbl where StFees < 13500"
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        StudentsDGV.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub Reset()
        StNameTb.Text = ""
        StFatherTb.Text = ""
        FeesTb.Text = ""
        StDOB.ResetText()
        StMobileNoTb.Text = ""
        StAddressTb.Text = ""
        StGenderCb.Text = ""
        DepartmentsCb.Text = ""
        StSessionCb.Text = ""
        StSemesterCb.Text = ""
        StSearchTb.Text = ""
    End Sub

    Private Sub Students_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FillDepartment()
        DisplayStudents()
    End Sub

    Private Sub DurationTb_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub TeachersPicture_Click(sender As Object, e As EventArgs) Handles TeachersPicture.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersLabel_Click(sender As Object, e As EventArgs) Handles TeachersLabel.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsPicture_Click(sender As Object, e As EventArgs) Handles StudentsPicture.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsLabel_Click(sender As Object, e As EventArgs) Handles StudentsLabel.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesPicture_Click(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click(sender As Object, e As EventArgs) Handles FeesLabel.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardPicture_Click(sender As Object, e As EventArgs) Handles DashboardPicture.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardLabel_Click(sender As Object, e As EventArgs) Handles DashboardLabel.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub LogoutPicture_Click(sender As Object, e As EventArgs) Handles LogoutPicture.Click
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If StNameTb.Text = "" Or StFatherTb.Text = "" Or FeesTb.Text = "" Or StMobileNoTb.Text = "" Or StAddressTb.Text = "" Or StGenderCb.Text = "" Or DepartmentsCb.Text = "" Or StSemesterCb.Text = "" Or StSessionCb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "insert into StudentsTbl values('" & StNameTb.Text & "','" & StFatherTb.Text & "','" & StGenderCb.Text.ToString() & "','" & StDOB.Value.Date & "','" & StMobileNoTb.Text & "','" & StAddressTb.Text & "','" & DepartmentsCb.Text.ToString() & "','" & StSemesterCb.Text.ToString() & "','" & StSessionCb.Text.ToString() & "'," & FeesTb.Text & ")"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student saved Successfully")
                Con.Close()
                DisplayStudents()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If StNameTb.Text = "" Or StFatherTb.Text = "" Or FeesTb.Text = "" Or StMobileNoTb.Text = "" Or StAddressTb.Text = "" Or StGenderCb.Text = "" Or DepartmentsCb.Text = "" Or StSemesterCb.Text = "" Or StSessionCb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "update StudentsTbl set StName='" & StNameTb.Text & "', StFatherName='" & StFatherTb.Text & "',StGender='" & StGenderCb.Text.ToString() & "',StDOB='" & StDOB.Text & "',StPhone='" & StMobileNoTb.Text & "',StAddress='" & StAddressTb.Text & "',StDept='" & DepartmentsCb.Text.ToString() & "',StSemester='" & StSemesterCb.Text.ToString() & "',StSession='" & StSessionCb.Text.ToString() & "',StFees=" & FeesTb.Text & " where StId=" & Key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student updated Successfully")
                Con.Close()
                DisplayStudents()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Key = 0 Then
            MsgBox("Please Select the Student to Delete")
        Else
            Try
                Con.Open()
                Dim query = "delete from StudentsTbl where StId=" & Key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student Deleted Successfully")
                Con.Close()
                DisplayStudents()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub
    Dim Key = 0

    Private Sub StudentsDGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles StudentsDGV.CellContentClick
        Dim row As DataGridViewRow = StudentsDGV.Rows(e.RowIndex)
        StNameTb.Text = row.Cells(1).Value.ToString
        StFatherTb.Text = row.Cells(2).Value.ToString
        StGenderCb.Text = row.Cells(3).Value.ToString
        StDOB.Text = row.Cells(4).Value.ToString
        StMobileNoTb.Text = row.Cells(5).Value.ToString
        StAddressTb.Text = row.Cells(6).Value.ToString
        DepartmentsCb.Text = row.Cells(7).Value.ToString
        StSemesterCb.Text = row.Cells(8).Value.ToString
        StSessionCb.Text = row.Cells(9).Value.ToString
        FeesTb.Text = row.Cells(10).Value.ToString
        If StNameTb.Text = "" Then
            Key = 0
        Else
            Key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnNoDueList_Click(sender As Object, e As EventArgs) Handles btnNoDueList.Click
        NoDueList()
    End Sub

    Private Sub btnReload_Click(sender As Object, e As EventArgs) Handles btnReload.Click
        DisplayStudents()
        'StSearchTb.Text = ""
    End Sub

    Private Sub Students_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Application.Exit()
    End Sub

    Private Sub StNameTb_KeyDown(sender As Object, e As KeyEventArgs) Handles StNameTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub StGenderCb_KeyDown(sender As Object, e As KeyEventArgs) Handles StGenderCb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub StDOB_KeyDown(sender As Object, e As KeyEventArgs) Handles StDOB.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub StMobileNoTb_KeyDown(sender As Object, e As KeyEventArgs) Handles StMobileNoTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub DepartmentsCb_KeyDown(sender As Object, e As KeyEventArgs) Handles DepartmentsCb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub FeesTb_KeyDown(sender As Object, e As KeyEventArgs) Handles FeesTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub StNameTb_TextChanged(sender As Object, e As EventArgs) Handles StNameTb.TextChanged
        'If Not IsNumeric(StNameTb.Text) Then


        '    ErrorProvider1.SetError(StNameTb, "")

        'Else
        '    ErrorProvider1.SetError(StNameTb, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    StNameTb.Clear()
        'End If
    End Sub

    Private Sub StMobileNoTb_TextChanged(sender As Object, e As EventArgs) Handles StMobileNoTb.TextChanged
        '        If IsNumeric(StMobileNoTb.Text) Then
        '            ErrorProvider1.SetError(StMobileNoTb, "")
        '        Else
        '            ErrorProvider1.SetError(StMobileNoTb, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Mobile Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            StMobileNoTb.Clear()
        '        End If
    End Sub

    Private Sub FeesTb_TextChanged(sender As Object, e As EventArgs) Handles FeesTb.TextChanged
        '        If IsNumeric(FeesTb.Text) Then
        '            ErrorProvider1.SetError(FeesTb, "")
        '        Else
        '            ErrorProvider1.SetError(FeesTb, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            FeesTb.Clear()
        '        End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles StbtnSearch.Click
        Dim cmd As New SqlCommand("select * from StudentsTbl where StId='" & StSearchTb.Text & "'", Con)

        Dim sda As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        sda.Fill(dt)
        StudentsDGV.DataSource = dt

    End Sub

    Private Sub StSearchTb_TextChanged(sender As Object, e As EventArgs) Handles StSearchTb.TextChanged
        '        If IsNumeric(StSearchTb.Text) Then
        '            ErrorProvider1.SetError(StSearchTb, "")
        '        Else
        '            ErrorProvider1.SetError(StSearchTb, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            StSearchTb.Clear()
        '        End If
    End Sub

    Private Sub StMobileNoTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles StMobileNoTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Mobile Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub FeesTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles FeesTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Integer Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub StNameTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles StNameTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghi jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub GunaCirclePictureBox1_Click(sender As Object, e As EventArgs) Handles GunaCirclePictureBox1.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StSearchTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles StSearchTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 123456789
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid ID Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub StAddressTb_KeyDown(sender As Object, e As KeyEventArgs)

        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub StAddressTb_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghi jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub StFatherTb_KeyDown(sender As Object, e As KeyEventArgs) Handles StFatherTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub StFatherTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles StFatherTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghi jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub ComboBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles StSemesterCb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles StSessionCb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        Dim Obj = New Upgrade()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label16_Click(sender As Object, e As EventArgs) Handles Label16.Click
        Dim Obj = New Upgrade()
        Obj.Show()
        Me.Hide()
    End Sub
End Class