﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Attendace
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Attendace))
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GunaCirclePictureBox1 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.LogoutPicture = New System.Windows.Forms.PictureBox()
        Me.DashboardLabel = New System.Windows.Forms.Label()
        Me.FeesLabel = New System.Windows.Forms.Label()
        Me.StudentsLabel = New System.Windows.Forms.Label()
        Me.TeachersLabel = New System.Windows.Forms.Label()
        Me.DashboardPicture = New System.Windows.Forms.PictureBox()
        Me.FeesPicture = New System.Windows.Forms.PictureBox()
        Me.StudentsPicture = New System.Windows.Forms.PictureBox()
        Me.TeachersPicture = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.AttStStauscb = New System.Windows.Forms.ComboBox()
        Me.AttStDateDtp = New System.Windows.Forms.DateTimePicker()
        Me.AttendanceDGV = New Guna.UI.WinForms.GunaDataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnAttSave = New System.Windows.Forms.Button()
        Me.btnAttUpdate = New System.Windows.Forms.Button()
        Me.btnAttDelete = New System.Windows.Forms.Button()
        Me.btnAttReset = New System.Windows.Forms.Button()
        Me.AttStNameTb = New System.Windows.Forms.TextBox()
        Me.AttStIDCb = New System.Windows.Forms.ComboBox()
        Me.StbtnSearch = New System.Windows.Forms.Button()
        Me.StSearchTb = New System.Windows.Forms.TextBox()
        Me.btnReload = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AttendanceDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Purple
        Me.Panel1.Controls.Add(Me.GunaCirclePictureBox1)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.PictureBox10)
        Me.Panel1.Controls.Add(Me.PictureBox9)
        Me.Panel1.Controls.Add(Me.LogoutPicture)
        Me.Panel1.Controls.Add(Me.DashboardLabel)
        Me.Panel1.Controls.Add(Me.FeesLabel)
        Me.Panel1.Controls.Add(Me.StudentsLabel)
        Me.Panel1.Controls.Add(Me.TeachersLabel)
        Me.Panel1.Controls.Add(Me.DashboardPicture)
        Me.Panel1.Controls.Add(Me.FeesPicture)
        Me.Panel1.Controls.Add(Me.StudentsPicture)
        Me.Panel1.Controls.Add(Me.TeachersPicture)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(220, 643)
        Me.Panel1.TabIndex = 76
        '
        'GunaCirclePictureBox1
        '
        Me.GunaCirclePictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaCirclePictureBox1.Image = Global.College_Management_System.My.Resources.Resources.images3
        Me.GunaCirclePictureBox1.Location = New System.Drawing.Point(1, 145)
        Me.GunaCirclePictureBox1.Name = "GunaCirclePictureBox1"
        Me.GunaCirclePictureBox1.Size = New System.Drawing.Size(73, 67)
        Me.GunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox1.TabIndex = 94
        Me.GunaCirclePictureBox1.TabStop = False
        Me.GunaCirclePictureBox1.UseTransfarantBackground = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(85, 463)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(71, 23)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "Events"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(77, 383)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(104, 23)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "Dasboard"
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(0, 434)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(75, 67)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 14
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(0, 361)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(75, 67)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 13
        Me.PictureBox9.TabStop = False
        '
        'LogoutPicture
        '
        Me.LogoutPicture.Image = CType(resources.GetObject("LogoutPicture.Image"), System.Drawing.Image)
        Me.LogoutPicture.Location = New System.Drawing.Point(-1, 579)
        Me.LogoutPicture.Name = "LogoutPicture"
        Me.LogoutPicture.Size = New System.Drawing.Size(74, 64)
        Me.LogoutPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.LogoutPicture.TabIndex = 12
        Me.LogoutPicture.TabStop = False
        '
        'DashboardLabel
        '
        Me.DashboardLabel.AutoSize = True
        Me.DashboardLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DashboardLabel.ForeColor = System.Drawing.Color.White
        Me.DashboardLabel.Location = New System.Drawing.Point(77, 309)
        Me.DashboardLabel.Name = "DashboardLabel"
        Me.DashboardLabel.Size = New System.Drawing.Size(134, 23)
        Me.DashboardLabel.TabIndex = 3
        Me.DashboardLabel.Text = "Fees Deposit"
        '
        'FeesLabel
        '
        Me.FeesLabel.AutoSize = True
        Me.FeesLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FeesLabel.ForeColor = System.Drawing.Color.White
        Me.FeesLabel.Location = New System.Drawing.Point(77, 238)
        Me.FeesLabel.Name = "FeesLabel"
        Me.FeesLabel.Size = New System.Drawing.Size(97, 23)
        Me.FeesLabel.TabIndex = 2
        Me.FeesLabel.Text = "Teachers"
        '
        'StudentsLabel
        '
        Me.StudentsLabel.AutoSize = True
        Me.StudentsLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsLabel.ForeColor = System.Drawing.Color.White
        Me.StudentsLabel.Location = New System.Drawing.Point(77, 162)
        Me.StudentsLabel.Name = "StudentsLabel"
        Me.StudentsLabel.Size = New System.Drawing.Size(134, 23)
        Me.StudentsLabel.TabIndex = 1
        Me.StudentsLabel.Text = "Departments"
        '
        'TeachersLabel
        '
        Me.TeachersLabel.AutoSize = True
        Me.TeachersLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TeachersLabel.ForeColor = System.Drawing.Color.White
        Me.TeachersLabel.Location = New System.Drawing.Point(85, 94)
        Me.TeachersLabel.Name = "TeachersLabel"
        Me.TeachersLabel.Size = New System.Drawing.Size(91, 23)
        Me.TeachersLabel.TabIndex = 0
        Me.TeachersLabel.Text = "Students"
        '
        'DashboardPicture
        '
        Me.DashboardPicture.Image = CType(resources.GetObject("DashboardPicture.Image"), System.Drawing.Image)
        Me.DashboardPicture.Location = New System.Drawing.Point(-1, 289)
        Me.DashboardPicture.Name = "DashboardPicture"
        Me.DashboardPicture.Size = New System.Drawing.Size(75, 67)
        Me.DashboardPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DashboardPicture.TabIndex = 7
        Me.DashboardPicture.TabStop = False
        '
        'FeesPicture
        '
        Me.FeesPicture.Image = CType(resources.GetObject("FeesPicture.Image"), System.Drawing.Image)
        Me.FeesPicture.Location = New System.Drawing.Point(0, 217)
        Me.FeesPicture.Name = "FeesPicture"
        Me.FeesPicture.Size = New System.Drawing.Size(73, 67)
        Me.FeesPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FeesPicture.TabIndex = 6
        Me.FeesPicture.TabStop = False
        '
        'StudentsPicture
        '
        Me.StudentsPicture.Image = CType(resources.GetObject("StudentsPicture.Image"), System.Drawing.Image)
        Me.StudentsPicture.Location = New System.Drawing.Point(0, 145)
        Me.StudentsPicture.Name = "StudentsPicture"
        Me.StudentsPicture.Size = New System.Drawing.Size(73, 67)
        Me.StudentsPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.StudentsPicture.TabIndex = 5
        Me.StudentsPicture.TabStop = False
        '
        'TeachersPicture
        '
        Me.TeachersPicture.Image = CType(resources.GetObject("TeachersPicture.Image"), System.Drawing.Image)
        Me.TeachersPicture.Location = New System.Drawing.Point(0, 73)
        Me.TeachersPicture.Name = "TeachersPicture"
        Me.TeachersPicture.Size = New System.Drawing.Size(73, 67)
        Me.TeachersPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.TeachersPicture.TabIndex = 4
        Me.TeachersPicture.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Location = New System.Drawing.Point(0, -3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(220, 71)
        Me.Panel2.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(73, 67)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.OliveDrab
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.btnClose)
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(220, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(861, 68)
        Me.Panel3.TabIndex = 77
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(621, -2)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(67, 67)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Transparent
        Me.btnClose.Image = CType(resources.GetObject("btnClose.Image"), System.Drawing.Image)
        Me.btnClose.Location = New System.Drawing.Point(793, 3)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(68, 64)
        Me.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnClose.TabIndex = 5
        Me.btnClose.TabStop = False
        Me.btnClose.UseWaitCursor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, 1)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(65, 68)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(366, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(114, 25)
        Me.Label2.TabIndex = 78
        Me.Label2.Text = "Student ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(644, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(149, 25)
        Me.Label3.TabIndex = 79
        Me.Label3.Text = "Student Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(386, 133)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 25)
        Me.Label4.TabIndex = 80
        Me.Label4.Text = "Date"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(684, 133)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(190, 25)
        Me.Label5.TabIndex = 81
        Me.Label5.Text = "Attendance Status"
        '
        'AttStStauscb
        '
        Me.AttStStauscb.FormattingEnabled = True
        Me.AttStStauscb.Items.AddRange(New Object() {"Present", "Absent", "Leave"})
        Me.AttStStauscb.Location = New System.Drawing.Point(912, 132)
        Me.AttStStauscb.Name = "AttStStauscb"
        Me.AttStStauscb.Size = New System.Drawing.Size(108, 25)
        Me.AttStStauscb.TabIndex = 2
        '
        'AttStDateDtp
        '
        Me.AttStDateDtp.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.AttStDateDtp.Location = New System.Drawing.Point(466, 132)
        Me.AttStDateDtp.Name = "AttStDateDtp"
        Me.AttStDateDtp.Size = New System.Drawing.Size(121, 23)
        Me.AttStDateDtp.TabIndex = 1
        '
        'AttendanceDGV
        '
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.White
        Me.AttendanceDGV.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle13
        Me.AttendanceDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.AttendanceDGV.BackgroundColor = System.Drawing.Color.White
        Me.AttendanceDGV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.AttendanceDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.AttendanceDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AttendanceDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.AttendanceDGV.ColumnHeadersHeight = 30
        Me.AttendanceDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.AttendanceDGV.DefaultCellStyle = DataGridViewCellStyle15
        Me.AttendanceDGV.EnableHeadersVisualStyles = False
        Me.AttendanceDGV.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AttendanceDGV.Location = New System.Drawing.Point(269, 332)
        Me.AttendanceDGV.Name = "AttendanceDGV"
        Me.AttendanceDGV.ReadOnly = True
        Me.AttendanceDGV.RowHeadersVisible = False
        Me.AttendanceDGV.RowHeadersWidth = 62
        Me.AttendanceDGV.RowTemplate.Height = 28
        Me.AttendanceDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.AttendanceDGV.Size = New System.Drawing.Size(761, 269)
        Me.AttendanceDGV.TabIndex = 86
        Me.AttendanceDGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna
        Me.AttendanceDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.AttendanceDGV.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.AttendanceDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.AttendanceDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.AttendanceDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.AttendanceDGV.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.AttendanceDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AttendanceDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AttendanceDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.AttendanceDGV.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AttendanceDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.AttendanceDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.AttendanceDGV.ThemeStyle.HeaderStyle.Height = 30
        Me.AttendanceDGV.ThemeStyle.ReadOnly = True
        Me.AttendanceDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White
        Me.AttendanceDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.AttendanceDGV.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AttendanceDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.AttendanceDGV.ThemeStyle.RowsStyle.Height = 28
        Me.AttendanceDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AttendanceDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(508, 289)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(227, 32)
        Me.Label6.TabIndex = 87
        Me.Label6.Text = "Attendance List"
        '
        'btnAttSave
        '
        Me.btnAttSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAttSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAttSave.ForeColor = System.Drawing.Color.White
        Me.btnAttSave.Location = New System.Drawing.Point(315, 198)
        Me.btnAttSave.Name = "btnAttSave"
        Me.btnAttSave.Size = New System.Drawing.Size(107, 43)
        Me.btnAttSave.TabIndex = 3
        Me.btnAttSave.Text = "Save"
        Me.btnAttSave.UseVisualStyleBackColor = False
        '
        'btnAttUpdate
        '
        Me.btnAttUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAttUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAttUpdate.ForeColor = System.Drawing.Color.White
        Me.btnAttUpdate.Location = New System.Drawing.Point(457, 198)
        Me.btnAttUpdate.Name = "btnAttUpdate"
        Me.btnAttUpdate.Size = New System.Drawing.Size(99, 43)
        Me.btnAttUpdate.TabIndex = 4
        Me.btnAttUpdate.Text = "Update"
        Me.btnAttUpdate.UseVisualStyleBackColor = False
        '
        'btnAttDelete
        '
        Me.btnAttDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAttDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAttDelete.ForeColor = System.Drawing.Color.White
        Me.btnAttDelete.Location = New System.Drawing.Point(609, 198)
        Me.btnAttDelete.Name = "btnAttDelete"
        Me.btnAttDelete.Size = New System.Drawing.Size(104, 43)
        Me.btnAttDelete.TabIndex = 5
        Me.btnAttDelete.Text = "Delete"
        Me.btnAttDelete.UseVisualStyleBackColor = False
        '
        'btnAttReset
        '
        Me.btnAttReset.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAttReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAttReset.ForeColor = System.Drawing.Color.White
        Me.btnAttReset.Location = New System.Drawing.Point(747, 198)
        Me.btnAttReset.Name = "btnAttReset"
        Me.btnAttReset.Size = New System.Drawing.Size(109, 43)
        Me.btnAttReset.TabIndex = 6
        Me.btnAttReset.Text = "Reset"
        Me.btnAttReset.UseVisualStyleBackColor = False
        '
        'AttStNameTb
        '
        Me.AttStNameTb.Enabled = False
        Me.AttStNameTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AttStNameTb.Location = New System.Drawing.Point(810, 88)
        Me.AttStNameTb.MaxLength = 20
        Me.AttStNameTb.Name = "AttStNameTb"
        Me.AttStNameTb.Size = New System.Drawing.Size(115, 27)
        Me.AttStNameTb.TabIndex = 92
        '
        'AttStIDCb
        '
        Me.AttStIDCb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AttStIDCb.FormattingEnabled = True
        Me.AttStIDCb.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.AttStIDCb.Location = New System.Drawing.Point(494, 93)
        Me.AttStIDCb.Name = "AttStIDCb"
        Me.AttStIDCb.Size = New System.Drawing.Size(108, 27)
        Me.AttStIDCb.TabIndex = 0
        '
        'StbtnSearch
        '
        Me.StbtnSearch.BackColor = System.Drawing.Color.DarkOrange
        Me.StbtnSearch.FlatAppearance.BorderSize = 0
        Me.StbtnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StbtnSearch.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StbtnSearch.ForeColor = System.Drawing.Color.White
        Me.StbtnSearch.Location = New System.Drawing.Point(898, 264)
        Me.StbtnSearch.Name = "StbtnSearch"
        Me.StbtnSearch.Size = New System.Drawing.Size(94, 41)
        Me.StbtnSearch.TabIndex = 95
        Me.StbtnSearch.Text = "Search"
        Me.StbtnSearch.UseVisualStyleBackColor = False
        '
        'StSearchTb
        '
        Me.StSearchTb.Location = New System.Drawing.Point(750, 275)
        Me.StSearchTb.MaxLength = 3
        Me.StSearchTb.Name = "StSearchTb"
        Me.StSearchTb.Size = New System.Drawing.Size(106, 23)
        Me.StSearchTb.TabIndex = 94
        '
        'btnReload
        '
        Me.btnReload.BackColor = System.Drawing.Color.DarkOrange
        Me.btnReload.FlatAppearance.BorderSize = 0
        Me.btnReload.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReload.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReload.ForeColor = System.Drawing.Color.White
        Me.btnReload.Location = New System.Drawing.Point(898, 200)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(94, 41)
        Me.btnReload.TabIndex = 93
        Me.btnReload.Text = "Reload"
        Me.btnReload.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Wide Latin", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(186, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(294, 34)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Attendance"
        '
        'Attendace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1081, 643)
        Me.Controls.Add(Me.StbtnSearch)
        Me.Controls.Add(Me.StSearchTb)
        Me.Controls.Add(Me.btnReload)
        Me.Controls.Add(Me.AttStIDCb)
        Me.Controls.Add(Me.AttStNameTb)
        Me.Controls.Add(Me.btnAttReset)
        Me.Controls.Add(Me.btnAttDelete)
        Me.Controls.Add(Me.btnAttUpdate)
        Me.Controls.Add(Me.btnAttSave)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.AttendanceDGV)
        Me.Controls.Add(Me.AttStDateDtp)
        Me.Controls.Add(Me.AttStStauscb)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Attendace"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Attendace"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AttendanceDGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents LogoutPicture As PictureBox
    Friend WithEvents DashboardLabel As Label
    Friend WithEvents FeesLabel As Label
    Friend WithEvents StudentsLabel As Label
    Friend WithEvents TeachersLabel As Label
    Friend WithEvents DashboardPicture As PictureBox
    Friend WithEvents FeesPicture As PictureBox
    Friend WithEvents StudentsPicture As PictureBox
    Friend WithEvents TeachersPicture As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnClose As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents AttStStauscb As ComboBox
    Friend WithEvents AttStDateDtp As DateTimePicker
    Friend WithEvents AttendanceDGV As Guna.UI.WinForms.GunaDataGridView
    Friend WithEvents Label6 As Label
    Friend WithEvents btnAttSave As Button
    Friend WithEvents btnAttUpdate As Button
    Friend WithEvents btnAttDelete As Button
    Friend WithEvents btnAttReset As Button
    Friend WithEvents AttStNameTb As TextBox
    Friend WithEvents AttStIDCb As ComboBox
    Friend WithEvents GunaCirclePictureBox1 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents StbtnSearch As Button
    Friend WithEvents StSearchTb As TextBox
    Friend WithEvents btnReload As Button
    Friend WithEvents Label9 As Label
End Class
