﻿Imports System.Data.SqlClient
Public Class Teachers
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub FillDepartment()
        Con.Open()
        Dim query = "select * from DepartmentsTbl"
        Dim cmd As New SqlCommand(query, Con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim Tbl As New DataTable()
        adapter.Fill(Tbl)
        DepartmentsCb.DataSource = Tbl
        DepartmentsCb.DisplayMember = "DeptName"
        DepartmentsCb.ValueMember = "DeptName"
        Con.Close()
    End Sub
    Private Sub DisplayTeachers()
        Con.Open()
        Dim query = "select * from TeachersTbl"
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        TeachersDGV.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub Reset()
        TNameTb.Text = ""
        TGenderCb.Text = ""
        TDOB.ResetText()
        TMobileNoTb.Text = ""
        DepartmentsCb.Text = ""
        TAddressTb.Text = ""
    End Sub

    Private Sub TeachersPicture_Click(sender As Object, e As EventArgs) Handles TeachersPicture.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersLabel_Click(sender As Object, e As EventArgs) Handles TeachersLabel.Click

    End Sub

    Private Sub TeachersLabel_Click_1(sender As Object, e As EventArgs) Handles TeachersLabel.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersPicture_Click_1(sender As Object, e As EventArgs) Handles TeachersPicture.Click, TeachersPicture.Click, TeachersPicture.Click

    End Sub

    Private Sub TeachersLabel_Click_2(sender As Object, e As EventArgs) Handles TeachersLabel.Click, TeachersLabel.Click

    End Sub

    Private Sub DashboardPicture_Click(sender As Object, e As EventArgs) Handles DashboardPicture.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardLabel_Click(sender As Object, e As EventArgs) Handles DashboardLabel.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesPicture_Click(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click(sender As Object, e As EventArgs) Handles FeesLabel.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsPicture_Click(sender As Object, e As EventArgs) Handles StudentsPicture.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsLabel_Click(sender As Object, e As EventArgs) Handles StudentsLabel.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersPicture_Click_2(sender As Object, e As EventArgs) Handles TeachersPicture.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersLabel_Click_3(sender As Object, e As EventArgs) Handles TeachersLabel.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub LogoutPicture_Click(sender As Object, e As EventArgs) Handles LogoutPicture.Click
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub

    Private Sub Teachers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayTeachers()
        FillDepartment()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If TNameTb.Text = "" Or TAddressTb.Text = "" Or TMobileNoTb.Text = "" Or TGenderCb.Text = "" Or DepartmentsCb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "insert into TeachersTbl values('" & TNameTb.Text & "','" & TGenderCb.Text.ToString() & "','" & TDOB.Value.Date & "','" & TMobileNoTb.Text & "','" & DepartmentsCb.Text.ToString() & "','" & TAddressTb.Text & "')"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Teacher saved Successfully")
                Con.Close()
                DisplayTeachers()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If TNameTb.Text = "" Or TAddressTb.Text = "" Or TMobileNoTb.Text = "" Or TGenderCb.Text = "" Or DepartmentsCb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "update TeachersTbl set TName='" & TNameTb.Text & "',TGender='" & TGenderCb.Text.ToString() & "',TDOB='" & TDOB.Text & "',TPhone='" & TMobileNoTb.Text & "',TDept='" & DepartmentsCb.Text.ToString() & "',TAdd='" & TAddressTb.Text & "' where TId=" & Key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Teacher updated Successfully")
                Con.Close()
                DisplayTeachers()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub
    Dim Key = 0

    Private Sub TeachersDGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles TeachersDGV.CellContentClick
        Dim row As DataGridViewRow = TeachersDGV.Rows(e.RowIndex)
        TNameTb.Text = row.Cells(1).Value.ToString
        TGenderCb.Text = row.Cells(2).Value.ToString
        TDOB.Text = row.Cells(3).Value.ToString
        TMobileNoTb.Text = row.Cells(4).Value.ToString
        DepartmentsCb.Text = row.Cells(5).Value.ToString
        TAddressTb.Text = row.Cells(6).Value.ToString

        If TNameTb.Text = "" Then
            Key = 0
        Else
            Key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Key = 0 Then
            MsgBox("Please Select the Teacher to Delete")
        Else
            Try
                Con.Open()
                Dim query = "delete from TeachersTbl where TId=" & Key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Teacher Deleted Successfully")
                Con.Close()
                DisplayTeachers()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub Teachers_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Application.Exit()
    End Sub

    Private Sub TeachersDGV_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles TeachersDGV.CellMouseClick

    End Sub

    Private Sub btnReload_Click(sender As Object, e As EventArgs) Handles btnReload.Click
        DisplayTeachers()
        'TSearchTb.Text = ""
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles TbtnSearch.Click
        Dim cmd As New SqlCommand("select * from TeachersTbl where TId='" & TSearchTb.Text & "'", Con)

        Dim sda As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        sda.Fill(dt)
        TeachersDGV.DataSource = dt
    End Sub

    Private Sub StSearchTb_TextChanged(sender As Object, e As EventArgs) Handles TSearchTb.TextChanged
        '        If IsNumeric(TSearchTb.Text) Then
        '            ErrorProvider1.SetError(TSearchTb, "")
        '        Else
        '            ErrorProvider1.SetError(TSearchTb, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TSearchTb.Clear()
        '        End If
    End Sub

    Private Sub TNameTb_KeyDown(sender As Object, e As KeyEventArgs) Handles TNameTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TGenderCb_KeyDown(sender As Object, e As KeyEventArgs) Handles TGenderCb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TDOB_KeyDown(sender As Object, e As KeyEventArgs) Handles TDOB.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TMobileNoTb_KeyDown(sender As Object, e As KeyEventArgs) Handles TMobileNoTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub DepartmentsCb_KeyDown(sender As Object, e As KeyEventArgs) Handles DepartmentsCb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TAddressTb_KeyDown(sender As Object, e As KeyEventArgs) Handles TAddressTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TNameTb_TextChanged(sender As Object, e As EventArgs) Handles TNameTb.TextChanged
        'If Not IsNumeric(TNameTb.Text) Then


        '    ErrorProvider1.SetError(TNameTb, "")

        'Else
        '    ErrorProvider1.SetError(TNameTb, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TNameTb.Clear()
        'End If

    End Sub

    Private Sub TMobileNoTb_TextChanged(sender As Object, e As EventArgs) Handles TMobileNoTb.TextChanged
        '        If IsNumeric(TMobileNoTb.Text) Then
        '            ErrorProvider1.SetError(TMobileNoTb, "")
        '        Else
        '            ErrorProvider1.SetError(TMobileNoTb, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Mobile Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TMobileNoTb.Clear()
        '        End If
    End Sub

    Private Sub TAddressTb_TextChanged(sender As Object, e As EventArgs) Handles TAddressTb.TextChanged
        'If Not IsNumeric(TAddressTb.Text) Then


        '    ErrorProvider1.SetError(TAddressTb, "")

        'Else
        '    ErrorProvider1.SetError(TAddressTb, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TAddressTb.Clear()
        'End If
    End Sub

    Private Sub TMobileNoTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TMobileNoTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Mobile Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TNameTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TNameTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmn opqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TAddressTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TAddressTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmn opqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Dispose()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Dispose()
    End Sub

    Private Sub GunaCirclePictureBox1_Click(sender As Object, e As EventArgs) Handles GunaCirclePictureBox1.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Dispose()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TSearchTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TSearchTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 123456789
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid ID Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class