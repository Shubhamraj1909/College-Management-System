﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.Linq

Public Class Form1

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub
    Dim startpoint = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        startpoint += 1
        ProgressBar1.Value = startpoint
        Percentagelbl.Text = startpoint & "%"
        If ProgressBar1.Value = 100 Then
            ProgressBar1.Value = 0
            Timer1.Stop()

            Me.Hide()
            Dim log = New Login
            log.Show()


        End If

        'ProgressBar1.Increment(1)
        'If ProgressBar1.Value = 100 Then
        '    Me.Hide()
        '    Dim log = New Login
        '    log.Show()
        '    Timer1.Enabled = False

        'End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
