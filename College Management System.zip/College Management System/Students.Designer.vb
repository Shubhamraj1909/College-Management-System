﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Students
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Students))
        Me.StudentsDGV = New Guna.UI.WinForms.GunaDataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.StNameTb = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DashboardLabel = New System.Windows.Forms.Label()
        Me.FeesLabel = New System.Windows.Forms.Label()
        Me.StudentsLabel = New System.Windows.Forms.Label()
        Me.TeachersLabel = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.GunaCirclePictureBox1 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.LogoutPicture = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.DashboardPicture = New System.Windows.Forms.PictureBox()
        Me.FeesPicture = New System.Windows.Forms.PictureBox()
        Me.StudentsPicture = New System.Windows.Forms.PictureBox()
        Me.TeachersPicture = New System.Windows.Forms.PictureBox()
        Me.StGenderCb = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.StDOB = New System.Windows.Forms.DateTimePicker()
        Me.StMobileNoTb = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FeesTb = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DepartmentsCb = New System.Windows.Forms.ComboBox()
        Me.btnReload = New System.Windows.Forms.Button()
        Me.btnNoDueList = New System.Windows.Forms.Button()
        Me.StSearchTb = New System.Windows.Forms.TextBox()
        Me.StbtnSearch = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.StFatherTb = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.StSemesterCb = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.StSessionCb = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.StAddressTb = New System.Windows.Forms.TextBox()
        CType(Me.StudentsDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StudentsDGV
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.StudentsDGV.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.StudentsDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.StudentsDGV.BackgroundColor = System.Drawing.Color.White
        Me.StudentsDGV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.StudentsDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.StudentsDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.Purple
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.StudentsDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.StudentsDGV.ColumnHeadersHeight = 25
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.StudentsDGV.DefaultCellStyle = DataGridViewCellStyle3
        Me.StudentsDGV.EnableHeadersVisualStyles = False
        Me.StudentsDGV.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.StudentsDGV.Location = New System.Drawing.Point(242, 357)
        Me.StudentsDGV.Name = "StudentsDGV"
        Me.StudentsDGV.RowHeadersVisible = False
        Me.StudentsDGV.RowHeadersWidth = 62
        Me.StudentsDGV.RowTemplate.Height = 28
        Me.StudentsDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.StudentsDGV.Size = New System.Drawing.Size(834, 255)
        Me.StudentsDGV.TabIndex = 28
        Me.StudentsDGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna
        Me.StudentsDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.StudentsDGV.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.StudentsDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.StudentsDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.StudentsDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.StudentsDGV.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.StudentsDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.StudentsDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Purple
        Me.StudentsDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.StudentsDGV.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.StudentsDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.StudentsDGV.ThemeStyle.HeaderStyle.Height = 25
        Me.StudentsDGV.ThemeStyle.ReadOnly = False
        Me.StudentsDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White
        Me.StudentsDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.StudentsDGV.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.StudentsDGV.ThemeStyle.RowsStyle.Height = 28
        Me.StudentsDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.StudentsDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(594, 324)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(161, 28)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Students Lists"
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.Color.DarkOrange
        Me.btnReset.FlatAppearance.BorderSize = 0
        Me.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReset.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.White
        Me.btnReset.Location = New System.Drawing.Point(933, 256)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(104, 49)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.DarkOrange
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(773, 256)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(106, 49)
        Me.btnDelete.TabIndex = 13
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.DarkOrange
        Me.btnUpdate.FlatAppearance.BorderSize = 0
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.Location = New System.Drawing.Point(618, 256)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(116, 49)
        Me.btnUpdate.TabIndex = 12
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.Color.DarkOrange
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(464, 256)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(120, 49)
        Me.btnSave.TabIndex = 11
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(954, 97)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(111, 23)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Mobile No"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(615, 97)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 23)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "Gender"
        '
        'StNameTb
        '
        Me.StNameTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StNameTb.Location = New System.Drawing.Point(259, 126)
        Me.StNameTb.MaxLength = 20
        Me.StNameTb.Name = "StNameTb"
        Me.StNameTb.Size = New System.Drawing.Size(142, 27)
        Me.StNameTb.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(255, 97)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(170, 23)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Students's Name"
        '
        'DashboardLabel
        '
        Me.DashboardLabel.AutoSize = True
        Me.DashboardLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DashboardLabel.ForeColor = System.Drawing.Color.White
        Me.DashboardLabel.Location = New System.Drawing.Point(89, 327)
        Me.DashboardLabel.Name = "DashboardLabel"
        Me.DashboardLabel.Size = New System.Drawing.Size(116, 23)
        Me.DashboardLabel.TabIndex = 11
        Me.DashboardLabel.Text = "Dashboard"
        '
        'FeesLabel
        '
        Me.FeesLabel.AutoSize = True
        Me.FeesLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FeesLabel.ForeColor = System.Drawing.Color.White
        Me.FeesLabel.Location = New System.Drawing.Point(81, 256)
        Me.FeesLabel.Name = "FeesLabel"
        Me.FeesLabel.Size = New System.Drawing.Size(134, 23)
        Me.FeesLabel.TabIndex = 10
        Me.FeesLabel.Text = "Fees Deposit"
        '
        'StudentsLabel
        '
        Me.StudentsLabel.AutoSize = True
        Me.StudentsLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsLabel.ForeColor = System.Drawing.Color.White
        Me.StudentsLabel.Location = New System.Drawing.Point(81, 174)
        Me.StudentsLabel.Name = "StudentsLabel"
        Me.StudentsLabel.Size = New System.Drawing.Size(134, 23)
        Me.StudentsLabel.TabIndex = 9
        Me.StudentsLabel.Text = "Departments"
        '
        'TeachersLabel
        '
        Me.TeachersLabel.AutoSize = True
        Me.TeachersLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TeachersLabel.ForeColor = System.Drawing.Color.White
        Me.TeachersLabel.Location = New System.Drawing.Point(89, 100)
        Me.TeachersLabel.Name = "TeachersLabel"
        Me.TeachersLabel.Size = New System.Drawing.Size(97, 23)
        Me.TeachersLabel.TabIndex = 8
        Me.TeachersLabel.Text = "Teachers"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DarkOrange
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Location = New System.Drawing.Point(0, -4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(225, 77)
        Me.Panel2.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(75, 72)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DarkOrange
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.btnClose)
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(215, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(890, 73)
        Me.Panel3.TabIndex = 16
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Wide Latin", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(272, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(235, 34)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Students"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(684, 1)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(70, 72)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Transparent
        Me.btnClose.Image = CType(resources.GetObject("btnClose.Image"), System.Drawing.Image)
        Me.btnClose.Location = New System.Drawing.Point(818, 3)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(72, 67)
        Me.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnClose.TabIndex = 5
        Me.btnClose.TabStop = False
        Me.btnClose.UseWaitCursor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(84, 73)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Purple
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.PictureBox4)
        Me.Panel1.Controls.Add(Me.GunaCirclePictureBox1)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.LogoutPicture)
        Me.Panel1.Controls.Add(Me.PictureBox10)
        Me.Panel1.Controls.Add(Me.PictureBox9)
        Me.Panel1.Controls.Add(Me.DashboardLabel)
        Me.Panel1.Controls.Add(Me.FeesLabel)
        Me.Panel1.Controls.Add(Me.StudentsLabel)
        Me.Panel1.Controls.Add(Me.TeachersLabel)
        Me.Panel1.Controls.Add(Me.DashboardPicture)
        Me.Panel1.Controls.Add(Me.FeesPicture)
        Me.Panel1.Controls.Add(Me.StudentsPicture)
        Me.Panel1.Controls.Add(Me.TeachersPicture)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(215, 690)
        Me.Panel1.TabIndex = 15
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(89, 565)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(94, 23)
        Me.Label16.TabIndex = 65
        Me.Label16.Text = "Upgrade"
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(2, 542)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(77, 72)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 37
        Me.PictureBox4.TabStop = False
        '
        'GunaCirclePictureBox1
        '
        Me.GunaCirclePictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaCirclePictureBox1.Image = Global.College_Management_System.My.Resources.Resources.images3
        Me.GunaCirclePictureBox1.Location = New System.Drawing.Point(2, 155)
        Me.GunaCirclePictureBox1.Name = "GunaCirclePictureBox1"
        Me.GunaCirclePictureBox1.Size = New System.Drawing.Size(75, 72)
        Me.GunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox1.TabIndex = 36
        Me.GunaCirclePictureBox1.TabStop = False
        Me.GunaCirclePictureBox1.UseTransfarantBackground = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(89, 497)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(71, 23)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Events"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(81, 410)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(126, 23)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Attendance"
        '
        'LogoutPicture
        '
        Me.LogoutPicture.Image = CType(resources.GetObject("LogoutPicture.Image"), System.Drawing.Image)
        Me.LogoutPicture.Location = New System.Drawing.Point(0, 631)
        Me.LogoutPicture.Name = "LogoutPicture"
        Me.LogoutPicture.Size = New System.Drawing.Size(61, 57)
        Me.LogoutPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.LogoutPicture.TabIndex = 12
        Me.LogoutPicture.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(0, 465)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(77, 72)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 18
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(0, 387)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(77, 72)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 17
        Me.PictureBox9.TabStop = False
        '
        'DashboardPicture
        '
        Me.DashboardPicture.Image = CType(resources.GetObject("DashboardPicture.Image"), System.Drawing.Image)
        Me.DashboardPicture.Location = New System.Drawing.Point(-2, 310)
        Me.DashboardPicture.Name = "DashboardPicture"
        Me.DashboardPicture.Size = New System.Drawing.Size(77, 72)
        Me.DashboardPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DashboardPicture.TabIndex = 7
        Me.DashboardPicture.TabStop = False
        '
        'FeesPicture
        '
        Me.FeesPicture.Image = CType(resources.GetObject("FeesPicture.Image"), System.Drawing.Image)
        Me.FeesPicture.Location = New System.Drawing.Point(0, 233)
        Me.FeesPicture.Name = "FeesPicture"
        Me.FeesPicture.Size = New System.Drawing.Size(75, 72)
        Me.FeesPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FeesPicture.TabIndex = 6
        Me.FeesPicture.TabStop = False
        '
        'StudentsPicture
        '
        Me.StudentsPicture.Image = CType(resources.GetObject("StudentsPicture.Image"), System.Drawing.Image)
        Me.StudentsPicture.Location = New System.Drawing.Point(2, 155)
        Me.StudentsPicture.Name = "StudentsPicture"
        Me.StudentsPicture.Size = New System.Drawing.Size(75, 72)
        Me.StudentsPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.StudentsPicture.TabIndex = 5
        Me.StudentsPicture.TabStop = False
        '
        'TeachersPicture
        '
        Me.TeachersPicture.Image = CType(resources.GetObject("TeachersPicture.Image"), System.Drawing.Image)
        Me.TeachersPicture.Location = New System.Drawing.Point(0, 78)
        Me.TeachersPicture.Name = "TeachersPicture"
        Me.TeachersPicture.Size = New System.Drawing.Size(75, 72)
        Me.TeachersPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.TeachersPicture.TabIndex = 4
        Me.TeachersPicture.TabStop = False
        '
        'StGenderCb
        '
        Me.StGenderCb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StGenderCb.FormattingEnabled = True
        Me.StGenderCb.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.StGenderCb.Location = New System.Drawing.Point(618, 123)
        Me.StGenderCb.Name = "StGenderCb"
        Me.StGenderCb.Size = New System.Drawing.Size(135, 27)
        Me.StGenderCb.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(787, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 23)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "D.O.B"
        '
        'StDOB
        '
        Me.StDOB.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StDOB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.StDOB.Location = New System.Drawing.Point(786, 123)
        Me.StDOB.Name = "StDOB"
        Me.StDOB.Size = New System.Drawing.Size(146, 27)
        Me.StDOB.TabIndex = 3
        '
        'StMobileNoTb
        '
        Me.StMobileNoTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StMobileNoTb.Location = New System.Drawing.Point(958, 123)
        Me.StMobileNoTb.MaxLength = 10
        Me.StMobileNoTb.Name = "StMobileNoTb"
        Me.StMobileNoTb.Size = New System.Drawing.Size(130, 27)
        Me.StMobileNoTb.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(946, 174)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(130, 23)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Annual Fees"
        '
        'FeesTb
        '
        Me.FeesTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FeesTb.Location = New System.Drawing.Point(950, 205)
        Me.FeesTb.MaxLength = 5
        Me.FeesTb.Name = "FeesTb"
        Me.FeesTb.Size = New System.Drawing.Size(138, 27)
        Me.FeesTb.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(442, 174)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(134, 23)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Departments"
        '
        'DepartmentsCb
        '
        Me.DepartmentsCb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DepartmentsCb.FormattingEnabled = True
        Me.DepartmentsCb.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.DepartmentsCb.Location = New System.Drawing.Point(445, 205)
        Me.DepartmentsCb.Name = "DepartmentsCb"
        Me.DepartmentsCb.Size = New System.Drawing.Size(139, 27)
        Me.DepartmentsCb.TabIndex = 6
        '
        'btnReload
        '
        Me.btnReload.BackColor = System.Drawing.Color.DarkOrange
        Me.btnReload.FlatAppearance.BorderSize = 0
        Me.btnReload.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReload.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReload.ForeColor = System.Drawing.Color.White
        Me.btnReload.Location = New System.Drawing.Point(464, 618)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(129, 56)
        Me.btnReload.TabIndex = 15
        Me.btnReload.Text = "Reload"
        Me.btnReload.UseVisualStyleBackColor = False
        '
        'btnNoDueList
        '
        Me.btnNoDueList.BackColor = System.Drawing.Color.DarkOrange
        Me.btnNoDueList.FlatAppearance.BorderSize = 0
        Me.btnNoDueList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNoDueList.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNoDueList.ForeColor = System.Drawing.Color.White
        Me.btnNoDueList.Location = New System.Drawing.Point(302, 256)
        Me.btnNoDueList.Name = "btnNoDueList"
        Me.btnNoDueList.Size = New System.Drawing.Size(123, 49)
        Me.btnNoDueList.TabIndex = 10
        Me.btnNoDueList.Text = "No Dues"
        Me.btnNoDueList.UseVisualStyleBackColor = False
        '
        'StSearchTb
        '
        Me.StSearchTb.Location = New System.Drawing.Point(637, 634)
        Me.StSearchTb.MaxLength = 3
        Me.StSearchTb.Name = "StSearchTb"
        Me.StSearchTb.Size = New System.Drawing.Size(109, 30)
        Me.StSearchTb.TabIndex = 16
        '
        'StbtnSearch
        '
        Me.StbtnSearch.BackColor = System.Drawing.Color.DarkOrange
        Me.StbtnSearch.FlatAppearance.BorderSize = 0
        Me.StbtnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StbtnSearch.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StbtnSearch.ForeColor = System.Drawing.Color.White
        Me.StbtnSearch.Location = New System.Drawing.Point(752, 618)
        Me.StbtnSearch.Name = "StbtnSearch"
        Me.StbtnSearch.Size = New System.Drawing.Size(112, 56)
        Me.StbtnSearch.TabIndex = 17
        Me.StbtnSearch.Text = "Search"
        Me.StbtnSearch.UseVisualStyleBackColor = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(262, 174)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 23)
        Me.Label12.TabIndex = 57
        Me.Label12.Text = "Address"
        '
        'StFatherTb
        '
        Me.StFatherTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StFatherTb.Location = New System.Drawing.Point(446, 123)
        Me.StFatherTb.MaxLength = 25
        Me.StFatherTb.Name = "StFatherTb"
        Me.StFatherTb.Size = New System.Drawing.Size(138, 27)
        Me.StFatherTb.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(448, 97)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(136, 23)
        Me.Label13.TabIndex = 59
        Me.Label13.Text = "Father Name"
        '
        'StSemesterCb
        '
        Me.StSemesterCb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StSemesterCb.FormattingEnabled = True
        Me.StSemesterCb.Items.AddRange(New Object() {"1st Semester", "2nd Semester", "3rd Semester", "4th Semester", "5th Semester", "6th Semester", "7th Semester", "8th Semester"})
        Me.StSemesterCb.Location = New System.Drawing.Point(618, 205)
        Me.StSemesterCb.Name = "StSemesterCb"
        Me.StSemesterCb.Size = New System.Drawing.Size(135, 27)
        Me.StSemesterCb.TabIndex = 7
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(614, 174)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(99, 23)
        Me.Label14.TabIndex = 61
        Me.Label14.Text = "Semester"
        '
        'StSessionCb
        '
        Me.StSessionCb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StSessionCb.FormattingEnabled = True
        Me.StSessionCb.Items.AddRange(New Object() {"2019-2022", "2020-2023", "2021-2024", "2022-2025", "2023-2026", "2024-2027", "2025-2028", "2026-2029", "2027-2030"})
        Me.StSessionCb.Location = New System.Drawing.Point(786, 205)
        Me.StSessionCb.Name = "StSessionCb"
        Me.StSessionCb.Size = New System.Drawing.Size(146, 27)
        Me.StSessionCb.TabIndex = 8
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(782, 174)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(81, 23)
        Me.Label15.TabIndex = 63
        Me.Label15.Text = "Session"
        '
        'StAddressTb
        '
        Me.StAddressTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StAddressTb.Location = New System.Drawing.Point(259, 205)
        Me.StAddressTb.Name = "StAddressTb"
        Me.StAddressTb.Size = New System.Drawing.Size(142, 27)
        Me.StAddressTb.TabIndex = 64
        '
        'Students
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1105, 690)
        Me.Controls.Add(Me.StAddressTb)
        Me.Controls.Add(Me.StSessionCb)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.StSemesterCb)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.StFatherTb)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.StbtnSearch)
        Me.Controls.Add(Me.StSearchTb)
        Me.Controls.Add(Me.btnNoDueList)
        Me.Controls.Add(Me.btnReload)
        Me.Controls.Add(Me.DepartmentsCb)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.FeesTb)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.StMobileNoTb)
        Me.Controls.Add(Me.StDOB)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.StGenderCb)
        Me.Controls.Add(Me.StudentsDGV)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.StNameTb)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "Students"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Students"
        CType(Me.StudentsDGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents StudentsDGV As Guna.UI.WinForms.GunaDataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents StNameTb As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnClose As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents LogoutPicture As PictureBox
    Friend WithEvents DashboardLabel As Label
    Friend WithEvents FeesLabel As Label
    Friend WithEvents StudentsLabel As Label
    Friend WithEvents TeachersLabel As Label
    Friend WithEvents DashboardPicture As PictureBox
    Friend WithEvents FeesPicture As PictureBox
    Friend WithEvents StudentsPicture As PictureBox
    Friend WithEvents TeachersPicture As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents StGenderCb As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents StDOB As DateTimePicker
    Friend WithEvents StMobileNoTb As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents FeesTb As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents DepartmentsCb As ComboBox
    Friend WithEvents btnReload As Button
    Friend WithEvents btnNoDueList As Button
    Friend WithEvents StbtnSearch As Button
    Friend WithEvents StSearchTb As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents GunaCirclePictureBox1 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents Label12 As Label
    Friend WithEvents StFatherTb As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents StSemesterCb As ComboBox
    Friend WithEvents Label14 As Label
    Friend WithEvents StSessionCb As ComboBox
    Friend WithEvents Label15 As Label
    Friend WithEvents StAddressTb As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents PictureBox4 As PictureBox
End Class
