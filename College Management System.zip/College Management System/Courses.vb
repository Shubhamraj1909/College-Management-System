﻿Imports System.Data.SqlClient
Public Class Courses
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub DisplayDepartments()
        Con.Open()
        Dim query = "select * from DepartmentsTbl"
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        GunaDataGridView1.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub Courses_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayDepartments()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub GunaButton1_Click(sender As Object, e As EventArgs) Handles GunaButton1.Click
        Dim Obj = New Student_Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub GunaCirclePictureBox7_Click(sender As Object, e As EventArgs) Handles GunaCirclePictureBox7.Click
        Application.Exit()
    End Sub
End Class