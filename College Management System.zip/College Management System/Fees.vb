﻿Imports System.Data.SqlClient
Public Class Fees
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub FillStudents()
        Con.Open()
        Dim query = "select * from StudentsTbl"
        Dim cmd As New SqlCommand(query, Con)
        Dim adapter As New SqlDataAdapter(cmd)
        Dim Tbl As New DataTable()
        adapter.Fill(Tbl)
        StIdCb.DataSource = Tbl
        StIdCb.DisplayMember = "StId"
        StIdCb.ValueMember = "StId"
        Con.Close()
    End Sub
    Private Sub DisplayPayments()
        Con.Open()
        Dim query = "select * from FeesTbl"
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        FeesDGV.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub Reset()
        AmountTb.Text = ""
        StNameTb.Text = ""
        StIdCb.SelectedIndex = -1
    End Sub
    Private Sub UpdateStudents()
        Try
            Con.Open()
            Dim query = "update StudentsTbl set StFees=" & AmountTb.Text & " where StId=" & StIdCb.SelectedValue.ToString() & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            MsgBox("Fees updated Successfully")
            Con.Close()
            DisplayPayments()
            Reset()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TNameTb_TextChanged(sender As Object, e As EventArgs) Handles StNameTb.TextChanged

    End Sub

    Private Sub StudentsPicture_Click(sender As Object, e As EventArgs) Handles StudentsPicture.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsLabel_Click(sender As Object, e As EventArgs) Handles StudentsLabel.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersPicture_Click(sender As Object, e As EventArgs) Handles TeachersPicture.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersLabel_Click(sender As Object, e As EventArgs) Handles TeachersLabel.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesPicture_Click(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click(sender As Object, e As EventArgs) Handles FeesLabel.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesPicture_Click_1(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click_1(sender As Object, e As EventArgs) Handles FeesLabel.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardLabel_Click(sender As Object, e As EventArgs) Handles DashboardLabel.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardPicture_Click(sender As Object, e As EventArgs) Handles DashboardPicture.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click_2(sender As Object, e As EventArgs) Handles FeesLabel.Click

    End Sub

    Private Sub FeesPicture_Click_2(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Fees_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayPayments()
        FillStudents()

    End Sub

    Private Sub LogoutPicture_Click(sender As Object, e As EventArgs) Handles LogoutPicture.Click
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub

    Private Sub btnPay_Click(sender As Object, e As EventArgs) Handles btnPay.Click
        If StNameTb.Text = "" Or AmountTb.Text = "" Then
            MsgBox("Missing Information .... !")
        ElseIf Convert.ToInt32(AmountTb.Text) > 100000 Or Convert.ToInt32(AmountTb.Text) < 1 Then
            MsgBox("Wrong Amount")
        Else
            Try
                Con.Open()
                Dim query = "insert into FeesTbl values(" & StIdCb.SelectedValue.ToString() & ",'" & StNameTb.Text & "','" & FeesDate.Value.Date & "'," & AmountTb.Text & ")"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Fees Paid Successfully")
                Con.Close()
                DisplayPayments()
                UpdateStudents()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
    Private Sub GetStName()
        Con.Open()
        Dim query = "select * from StudentsTbl where StId=" & StIdCb.SelectedValue.ToString() & ""
        Dim cmd As New SqlCommand(query, Con)
        Dim dt As New DataTable
        Dim reader As SqlDataReader
        reader = cmd.ExecuteReader()
        While reader.Read
            StNameTb.Text = reader(1).ToString()
        End While
        Con.Close()
    End Sub

    Private Sub StIdCb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles StIdCb.SelectedIndexChanged

    End Sub

    Private Sub TeachersDGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles FeesDGV.CellContentClick

    End Sub

    Private Sub StIdCb_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles StIdCb.SelectionChangeCommitted
        GetStName()
    End Sub

    Private Sub Fees_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Application.Exit()
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub GunaCirclePictureBox1_Click(sender As Object, e As EventArgs) Handles GunaCirclePictureBox1.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StNameTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles StNameTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub AmountTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles AmountTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show(" Please Enter Valid Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub StIdCb_KeyDown(sender As Object, e As KeyEventArgs) Handles StIdCb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub StNameTb_KeyDown(sender As Object, e As KeyEventArgs) Handles StNameTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub FeesDate_KeyDown(sender As Object, e As KeyEventArgs) Handles FeesDate.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub AmountTb_KeyDown(sender As Object, e As KeyEventArgs) Handles AmountTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub
End Class