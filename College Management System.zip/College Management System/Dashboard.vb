﻿Imports System.Data.SqlClient
Public Class Dashboard
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub CountStudents()
        Dim StNum As Integer
        Con.Open()
        Dim sql = "select COUNT(*) from StudentsTbl"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(sql, Con)
        StNum = cmd.ExecuteScalar
        lblNOS.Text = StNum
        Con.Close()
    End Sub
    Private Sub CountTeachers()
        Dim TNum As Integer
        Con.Open()
        Dim sql = "select COUNT(*) from TeachersTbl"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(sql, Con)
        TNum = cmd.ExecuteScalar
        lblNOT.Text = TNum
        Con.Close()
    End Sub
    Private Sub CountDepartments()
        Dim DeptNum As Integer
        Con.Open()
        Dim sql = "select COUNT(*) from DepartmentsTbl"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(sql, Con)
        DeptNum = cmd.ExecuteScalar
        lblNOD.Text = DeptNum
        Con.Close()
    End Sub
    Private Sub SumFees()
        Dim FeesAmount As Integer
        Con.Open()
        Dim sql = "select Sum(Amount) from FeesTbl"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(sql, Con)
        FeesAmount = cmd.ExecuteScalar
        lblSOF.Text = FeesAmount
        Con.Close()
    End Sub
    Private Sub Countenquiry()
        Dim StNum As Integer
        Con.Open()
        Dim sql = "select COUNT(*) from EnquiaryTbl"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(sql, Con)
        StNum = cmd.ExecuteScalar
        Label7.Text = StNum
        Con.Close()
    End Sub
    Private Sub Countevents()
        Dim SNum As Integer
        Con.Open()
        Dim sql = "select COUNT(*) from EventsTbl"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(sql, Con)
        SNum = cmd.ExecuteScalar
        Label4.Text = SNum
        Con.Close()
    End Sub
    Private Sub TeachersPicture_Click(sender As Object, e As EventArgs) Handles TeachersPicture.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersLabel_Click(sender As Object, e As EventArgs) Handles TeachersLabel.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsPicture_Click(sender As Object, e As EventArgs) Handles StudentsPicture.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsLabel_Click(sender As Object, e As EventArgs) Handles StudentsLabel.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesPicture_Click(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click(sender As Object, e As EventArgs) Handles FeesLabel.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardPicture_Click(sender As Object, e As EventArgs) Handles DashboardPicture.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardLabel_Click(sender As Object, e As EventArgs) Handles DashboardLabel.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CountStudents()
        CountTeachers()
        CountDepartments()
        SumFees()
        Countenquiry()
        Countevents()
    End Sub

    Private Sub LogoutPicture_Click(sender As Object, e As EventArgs) Handles LogoutPicture.Click
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub Dashboard_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Application.Exit()
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        Application.Exit()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub GunaCirclePictureBox3_Click(sender As Object, e As EventArgs) Handles GunaCirclePictureBox3.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub
End Class