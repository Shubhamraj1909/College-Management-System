﻿Imports System.Text
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Drawing.Drawing2D
Imports System.Text.RegularExpressions
Imports System.Data.SqlClient
Public Class Login
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    'CAptcha Code 'Captcha Code
    Dim DrawingFont As New Font("Arial", 25)
    Dim CaptchaImage As New Bitmap(140, 40)
    Dim CaptchaGraf As Graphics = Graphics.FromImage(CaptchaImage)
    Dim Alphabet As String = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz"
    Dim CaptchaString, TickRandom As String
    Dim ProcessNumber As Integer
    Private Sub GenerateCaptcha()
        ProcessNumber = My.Computer.Clock.LocalTime.Millisecond
        If ProcessNumber < 521 Then

            ProcessNumber \= 10
            CaptchaString = Alphabet.Substring(ProcessNumber, 1)
        Else

            CaptchaString = CStr(My.Computer.Clock.LocalTime.Second \ 6)
        End If

        ProcessNumber = My.Computer.Clock.LocalTime.Second
        If ProcessNumber < 30 Then
            ProcessNumber = Math.Abs(ProcessNumber - 8)
            CaptchaString += Alphabet.Substring(ProcessNumber, 1)
        Else

            CaptchaString += CStr(My.Computer.Clock.LocalTime.Minute \ 6)
        End If
        ProcessNumber =
My.Computer.Clock.LocalTime.DayOfYear
        If ProcessNumber Mod 2 = 0 Then
            ProcessNumber \= 8
            CaptchaString += Alphabet.Substring(ProcessNumber, 1)
        Else
            CaptchaString += CStr(ProcessNumber \ 37)
        End If
        TickRandom = My.Computer.Clock.TickCount.ToString
        ProcessNumber = Val(TickRandom.Substring(TickRandom.Length - 1, 1))
        If ProcessNumber Mod 2 = 0 Then
            CaptchaString += CStr(ProcessNumber)
        Else
            ProcessNumber = Math.Abs(Int(Math.Cos(Val(TickRandom)) * 51))
            CaptchaString += Alphabet.Substring(ProcessNumber, 1)
        End If
        ProcessNumber = My.Computer.Clock.LocalTime.Hour
        If ProcessNumber Mod 2 = 0 Then

            ProcessNumber = Math.Abs(Int(Math.Sin(Val(My.Computer.Clock.LocalTime.Year)) * 51))
            CaptchaString += Alphabet.Substring(ProcessNumber, 1)
        Else
            CaptchaString += CStr(ProcessNumber \ 3)
        End If

        ProcessNumber = My.Computer.Clock.LocalTime.Millisecond
        If ProcessNumber > 521 Then
            ProcessNumber = Math.Abs((ProcessNumber \ 10) - 52)
            CaptchaString +=
Alphabet.Substring(ProcessNumber, 1)
        Else


            CaptchaString += CStr(My.Computer.Clock.LocalTime.Second \ 6)
        End If
        CaptchaGraf.Clear(Color.White)
        For hasher As Integer = 0 To 5
            CaptchaGraf.DrawString(CaptchaString.Substring(hasher, 1), DrawingFont, Brushes.Black, hasher * 20 + hasher + ProcessNumber \ 200, (hasher Mod 3) * (ProcessNumber \ 200))
        Next
        PictureBox1.Image = CaptchaImage


    End Sub


    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GenerateCaptcha()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged
        If Not IsNumeric(txtUsername.Text) Then


            ErrorProvider1.SetError(txtUsername, "")

        Else
            ErrorProvider1.SetError(txtUsername, "")
            Dim result1 As DialogResult = MessageBox.Show("Please Enter Valid String:",
        "Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtUsername.Clear()
        End If
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click


        Dim cmd As New SqlCommand("select * from RegisterTbl where Username ='" + txtUsername.Text + "'and Pwd ='" + txtPassword.Text + "' and Role = '" + ComboBox1.SelectedItem + "'", Con)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        sda.Fill(dt)
        If (dt.Rows.Count > 0) Then
            ' MessageBox.Show("You are login as " + dt.Rows(0)(1))
            If (ComboBox1.SelectedIndex = 0) Then
                If TextBox4.Text = CaptchaString Then
                    'MsgBox("Captcha Correct", MsgBoxStyle.Information)
                    TextBox4.Clear()
                    GenerateCaptcha()
                    Dim a As New Departments
                    a.Show()
                    Me.Hide()
                Else
                    ErrorProvider1.SetError(TextBox4, "Please check captcha ")
                    ' MsgBox("Captcha Incorrect", MsgBoxStyle.Exclamation)
                    TextBox4.Clear()
                End If
            Else
                If TextBox4.Text = CaptchaString Then
                    TextBox4.Clear()
                    GenerateCaptcha()
                    Dim u As New Student_Dashboard
                    u.Show()
                    Me.Hide()

                Else
                    ErrorProvider1.SetError(TextBox4, "Please check captcha ")
                    ' MsgBox("Captcha Incorrect", MsgBoxStyle.Exclamation)
                    TextBox4.Clear()
                End If

            End If
        Else
            MessageBox.Show("Error")
            '  ErrorProvider1.SetError(TextBox4, "Please check captcha ")
        End If



        'If TextBox4.Text = "" And TextBox2.Text = "" And TextBox1.Text = "" Then
        '    '    '    'ErrorProvider1.SetError(TextBox1, "Must be fill up")
        '    '    '    'ErrorProvider1.SetError(TextBox2, "Must be fill up")
        '    '    '    'ErrorProvider1.SetError(TextBox4, "Must be fill up")
        '    '    '    'ErrorProvider1.SetError(ComboBox1, "Must be fill up")
        '    MessageBox.Show("You have not entered any information")


        'End If

        'If TextBox4.Text = CaptchaString Then
        '    'MsgBox("Captcha Correct", MsgBoxStyle.Information)
        '    TextBox4.Clear()
        '    GenerateCaptcha()

        '    con.Open()
        '    Dim cmd As New SqlCommand("select * from signup where username ='" + TextBox1.Text + "'and confirmpwd ='" + TextBox2.Text + "' and role = '" + ComboBox1.SelectedItem + "'", con)
        '    Dim adapter As New SqlDataAdapter(cmd)
        '    Dim table As New DataTable
        '    adapter.Fill(table)
        '    If table.Rows.Count() <= 0 Then
        '        MsgBox("Please enter valid password")

        '    Else
        '        MsgBox("Login Successfully")
        '        Form5.Show()
        '        Me.Hide()

        '    End If


        '    con.Close()


        'Else
        '    ErrorProvider1.SetError(TextBox4, "Please check captcha ")
        '    '  MsgBox("Captcha Incorrect", MsgBoxStyle.Exclamation)
        '    TextBox4.Clear()
        'End If


        ''If ComboBox1.SelectedItem = "Admin" Then

        ''    Form5.Show()
        ''    TextBox1.Clear()
        ''    TextBox2.Clear()
        ''    ComboBox1.SelectedIndex = -1
        ''Else
        ''    ComboBox1.SelectedItem = "User"
        ''    Form6.Show()

        ''    TextBox1.Clear()
        ''    TextBox2.Clear()
        ''    ComboBox1.SelectedIndex = -1

        ''End If
        GenerateCaptcha()
        txtUsername.Clear()
        txtPassword.Clear()
        TextBox4.Clear()
        ComboBox1.SelectedIndex = -1





        'If txtUsername.Text = "" Or txtPassword.Text = "" Then
        '    MsgBox("Please Enter Username & Password")
        'ElseIf txtUsername.Text = "Admin" And txtPassword.Text = "Password" Then
        '    Dim Obj = New Departments
        '    Obj.Show()
        '    Me.Hide()
        'Else
        '    MsgBox("Wrong Username & Password")
        '    txtUsername.Text = ""
        '    txtPassword.Text = ""
        'End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtUsername.Text = ""
        txtPassword.Text = ""
        TextBox4.Clear()
        ComboBox1.Text = ""

    End Sub

    Private Sub ForgotPassword_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
        MsgBox("Username is Admin and Password is Password", MsgBoxStyle.Information, "Forgot Password? & Please Write the Login Details")
    End Sub

    Private Sub PicLogo_Click(sender As Object, e As EventArgs) Handles PicLogo.Click
        MsgBox("Don't Angry me", MsgBoxStyle.Information, "College Management System")
    End Sub

    Private Sub PicLock_Click(sender As Object, e As EventArgs) Handles PicLock.Click
        MsgBox("Don't Angry me", MsgBoxStyle.Information, "College Management System")
    End Sub

    Private Sub RememberPassword_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ShowPassword_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        Dim regex As Regex = New Regex("[^a-zA-Z0-9]")
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            txtPassword.UseSystemPasswordChar = True

        Else
            txtPassword.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub txtUsername_KeyDown(sender As Object, e As KeyEventArgs) Handles txtUsername.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub txtPassword_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPassword.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox4_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox4.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Obj = New Register()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim Obj = New Forgot_Password()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowedchars As String = "abcdefghijklmnopqrstuvwxyz"
            Dim allowednos As String = "1234567890"

            If Not allowednos.Contains(e.KeyChar.ToString.ToLower) And Not allowedchars.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please Enter Valid Captcha")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        MsgBox("Please Enter User ID", MsgBoxStyle.Information, "College Management System")
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        MsgBox("Please Enter Password", MsgBoxStyle.Information, "College Management System")
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        MsgBox("Please Select Role", MsgBoxStyle.Information, "College Management System")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        GenerateCaptcha()
    End Sub
End Class