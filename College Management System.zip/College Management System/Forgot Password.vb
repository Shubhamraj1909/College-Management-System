﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
Public Class Forgot_Password
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            TextBox2.UseSystemPasswordChar = True

        Else
            TextBox2.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Dim regex As Regex = New Regex("[^a-zA-Z0-9]")
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        If TextBox2.Text = TextBox3.Text Then

            ' MessageBox.Show("Correct password", "Welcome college management system")
            ErrorProvider1.SetError(TextBox3, "")
        Else
            ErrorProvider1.SetError(TextBox3, " Not Match Password")
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If Not IsNumeric(TextBox1.Text) Then


            ErrorProvider1.SetError(TextBox1, "")

        Else
            ErrorProvider1.SetError(TextBox1, "")
            Dim result1 As DialogResult = MessageBox.Show("Please Enter Valid String:",
        "Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBox1.Clear()
        End If
    End Sub

    Private Sub Forgot_Password_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        ComboBox1.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim u As New Login
        u.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" And TextBox2.Text = "" And TextBox3.Text = "" Then
            MessageBox.Show("You have not entered any information")

        ElseIf TextBox1.Text = "" And TextBox2.Text = "" Then
            MessageBox.Show("Please enter valid username & password")

        ElseIf TextBox2.Text = "" And TextBox3.Text = "" Then
            MessageBox.Show("Please enter valid password")

        ElseIf TextBox1.Text = "" Then
            MessageBox.Show("Please enter valid username")

        ElseIf TextBox2.Text = "" Then
            MessageBox.Show("Please enter valid password")

        ElseIf TextBox3.Text = "" Then
            MessageBox.Show("Please confirm valid password")

        Else

            Dim cmd As New SqlCommand("update RegisterTbl set Pwd ='" + TextBox2.Text + "' ,  Confirmpwd ='" + TextBox3.Text + "' , Role ='" + ComboBox1.SelectedItem + "' where Username ='" + TextBox1.Text + "'", Con)
            Con.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Password Updated Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Con.Close()
        End If
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox3.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub
End Class