﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
Public Class Enquiry
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub Displayenquiry()
        Con.Open()
        Dim query = "select * from EnquiaryTbl "
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub Reset()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        ComboBox1.Text = ""
        DateTimePicker1.ResetText()
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
        TextBox10.Text = ""

    End Sub

    Private Sub DepartmentsTb_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Enquiry_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayEnquiry()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs)
        If TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.Text = "" Or ComboBox2.Text = "" Or
TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox3.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then

            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "insert into EnquiaryTbl values('" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & ComboBox1.Text.ToString() & "','" & DateTimePicker1.Value.Date & "','" & ComboBox2.Text.ToString() & "','" & TextBox5.Text & "',
'" & TextBox6.Text & "','" & ComboBox3.Text.ToString() & "','" & TextBox7.Text & "','" & TextBox8.Text & "',
'" & TextBox9.Text & "')"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student saved Successfully")
                Con.Close()
                Displayenquiry()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs)

        If TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.SelectedIndex = -1 Or ComboBox2.SelectedIndex = -1 Or
            TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox3.SelectedIndex = -1 Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then


            MsgBox("Missing Information .... !")
        Else
            'Try
            '    Con.Open()
            '    Dim query = "update EnquiaryTbl set StName='" & TextBox2.Text & "',StFName='" & TextBox3.Text & "',StMName='" & TextBox4.Text & "',
            'StGender = '" & ComboBox1.SelectedItem.ToString() & "',StDOB= '" & DateTimePicker1.Value.Date & "'
            ',StCategory='" & ComboBox2.SelectedItem.ToString() & "',
            'StPhone = '" & TextBox5.Text & "',StEmail='" & TextBox6.Text & "',StCourse= '" & ComboBox3.SelectedItem.ToString() & "',
            'StAddress = '" & TextBox7.Text & "', StCity= '" & TextBox8.Text & "',StState= '" & TextBox9.Text & "' where StId=" & key & ""
            '    ' Dim cmd As SqlCommand
            '    cmd = New SqlCommand(query, Con)
            '    cmd.ExecuteNonQuery()
            '    MsgBox("Student updated Successfully")
            '    Con.Close()
            '    Displayenquiry()
            '    Reset()
            'Catch ex As Exception
            'MsgBox(ex.Message)
            'End Try

            Con.Open()

            Dim cmd As New SqlCommand("update EnquiaryTbl set StName='" & TextBox2.Text & "',StFName='" & TextBox3.Text & "',StMName='" & TextBox4.Text & "',
                 StGender = '" & ComboBox1.Text.ToString() & "',StDOB= '" & DateTimePicker1.Value.Date & "',StCategory='" & ComboBox2.Text.ToString() & "',
            StPhone= '" & TextBox5.Text & "',StEmail='" & TextBox6.Text & "',StCourse= '" & ComboBox3.Text.ToString() & "',
                StAddress= '" & TextBox7.Text & "', StCity= '" & TextBox8.Text & "',StState= '" & TextBox9.Text & "' where StId ='" & key & "'", Con)
            cmd.ExecuteNonQuery()
            MsgBox("Data Updated Successfully")
            Con.Close()

        End If
        Reset()
        Displayenquiry()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs)
        If TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.SelectedIndex = -1 Or ComboBox2.SelectedIndex = -1 Or
            TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox3.SelectedIndex = -1 Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then

            MsgBox("Please ender the Student id to Delete")
        Else

            Con.Open()
            Dim cmd As New SqlCommand("delete EnquiaryTbl where StId ='" & key & "'", Con)
            cmd.ExecuteNonQuery()
            MsgBox("Deleted Successfully")
            Con.Close()
            Reset()
            Displayenquiry()
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs)
        Reset()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs)

    End Sub

    Private Sub GunaDataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
        ' TextBox1.Text = row.Cells(0).Value.ToString
        TextBox2.Text = row.Cells(1).Value.ToString
        TextBox3.Text = row.Cells(2).Value.ToString
        TextBox4.Text = row.Cells(3).Value.ToString

        ComboBox1.Text = row.Cells(4).Value.ToString
        DateTimePicker1.Value = row.Cells(5).Value.ToString
        ComboBox2.Text = row.Cells(6).Value.ToString
        TextBox5.Text = row.Cells(7).Value.ToString
        TextBox6.Text = row.Cells(8).Value.ToString
        ComboBox3.Text = row.Cells(9).Value.ToString
        TextBox7.Text = row.Cells(10).Value.ToString
        TextBox8.Text = row.Cells(11).Value.ToString
        TextBox9.Text = row.Cells(12).Value.ToString
        If TextBox2.Text = "" Then

            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub DataGridView1_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs)
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
        TextBox2.Text = row.Cells(1).Value.ToString
        TextBox3.Text = row.Cells(2).Value.ToString
        TextBox4.Text = row.Cells(3).Value.ToString

        ComboBox1.Text = row.Cells(4).Value.ToString
        DateTimePicker1.Value = row.Cells(5).Value.ToString
        ComboBox2.Text = row.Cells(6).Value.ToString
        TextBox5.Text = row.Cells(7).Value.ToString
        TextBox6.Text = row.Cells(8).Value.ToString
        ComboBox3.Text = row.Cells(9).Value.ToString
        TextBox7.Text = row.Cells(10).Value.ToString
        TextBox8.Text = row.Cells(11).Value.ToString
        TextBox9.Text = row.Cells(12).Value.ToString
        If TextBox2.Text = "" Then

            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.Text = "" Or ComboBox2.Text = "" Or
TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox3.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then

            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "insert into EnquiaryTbl values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & ComboBox1.Text.ToString() & "','" & DateTimePicker1.Value.Date & "','" & ComboBox2.Text.ToString() & "','" & TextBox5.Text & "',
'" & TextBox6.Text & "','" & ComboBox3.Text.ToString() & "','" & TextBox7.Text & "','" & TextBox8.Text & "',
'" & TextBox9.Text & "')"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student saved Successfully")
                Con.Close()
                Displayenquiry()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            '        Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.SelectedIndex = -1 Or ComboBox2.SelectedIndex = -1 Or
            'TextBox5.Text = "" Or TextBox6.Text = "" Or ComboBox3.SelectedIndex = -1 Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = ""


            MsgBox("Missing Information .... !")
        Else
            'Try
            '    Con.Open()
            '    Dim query = "update EnquiaryTbl set StName='" & TextBox2.Text & "',StFName='" & TextBox3.Text & "',StMName='" & TextBox4.Text & "',
            'StGender = '" & ComboBox1.SelectedItem.ToString() & "',StDOB= '" & DateTimePicker1.Value.Date & "'
            ',StCategory='" & ComboBox2.SelectedItem.ToString() & "',
            'StPhone = '" & TextBox5.Text & "',StEmail='" & TextBox6.Text & "',StCourse= '" & ComboBox3.SelectedItem.ToString() & "',
            'StAddress = '" & TextBox7.Text & "', StCity= '" & TextBox8.Text & "',StState= '" & TextBox9.Text & "' where StId=" & key & ""
            '    ' Dim cmd As SqlCommand
            '    cmd = New SqlCommand(query, Con)
            '    cmd.ExecuteNonQuery()
            '    MsgBox("Student updated Successfully")
            '    Con.Close()
            '    Displayenquiry()
            '    Reset()
            'Catch ex As Exception
            'MsgBox(ex.Message)
            'End Try

            Con.Open()

            Dim cmd As New SqlCommand("update EnquiaryTbl set StName='" & TextBox2.Text & "',StFName='" & TextBox3.Text & "',StMName='" & TextBox4.Text & "',
                 StGender = '" & ComboBox1.Text.ToString() & "',StDOB= '" & DateTimePicker1.Value.Date & "',StCategory='" & ComboBox2.Text.ToString() & "',
            StPhone= '" & TextBox5.Text & "',StEmail='" & TextBox6.Text & "',StCourse= '" & ComboBox3.Text.ToString() & "',
                StAddress= '" & TextBox7.Text & "', StCity= '" & TextBox8.Text & "',StState= '" & TextBox9.Text & "' where StId ='" & key & "'", Con)
            cmd.ExecuteNonQuery()
            MsgBox("Data Updated Successfully")
            Con.Close()

        End If
        Reset()
        Displayenquiry()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Then
            MsgBox("Please Select the Student ID to Delete")
        Else

            Con.Open()
            Dim cmd As New SqlCommand("delete EnquiaryTbl where StId ='" & TextBox1.Text & "'", Con)
            cmd.ExecuteNonQuery()
            MsgBox("Deleted Successfully")
            Con.Close()
            Reset()
            Displayenquiry()
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Reset()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Displayenquiry()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim cmd As New SqlCommand("select * from EnquiaryTbl where StId='" & TextBox10.Text & "'", Con)
        Dim sda As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        sda.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim Obj = New Student_Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DataGridView1_CellContentClick_2(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
    Dim key = 0
    Private Sub DataGridView1_CellMouseClick_1(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
        TextBox1.Text = row.Cells(0).Value.ToString
        TextBox2.Text = row.Cells(1).Value.ToString
        TextBox3.Text = row.Cells(2).Value.ToString
        TextBox4.Text = row.Cells(3).Value.ToString

        ComboBox1.Text = row.Cells(4).Value.ToString
        DateTimePicker1.Value = row.Cells(5).Value.ToString
        ComboBox2.Text = row.Cells(6).Value.ToString
        TextBox5.Text = row.Cells(7).Value.ToString
        TextBox6.Text = row.Cells(8).Value.ToString
        ComboBox3.Text = row.Cells(9).Value.ToString
        TextBox7.Text = row.Cells(10).Value.ToString
        TextBox8.Text = row.Cells(11).Value.ToString
        TextBox9.Text = row.Cells(12).Value.ToString
        If TextBox2.Text = "" Then

            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 123456789
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid ID Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox5_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox5.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Mobile Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox10_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox10.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 123456789
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Mobile Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox9_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox9.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox7_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox7.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox8_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox8.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        Dim regex As Regex = New Regex("^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
        Dim isValid As Boolean = regex.IsMatch(TextBox6.Text.Trim)
        If isValid Then
            ErrorProvider1.SetError(TextBox6, "")
            'MessageBox.Show("correct email")
        Else
            ErrorProvider1.SetError(TextBox6, "Enter Valid Email Id:")
            'MessageBox.Show("invalid Email.")
        End If
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox3.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox4_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox4.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub DateTimePicker1_KeyDown(sender As Object, e As KeyEventArgs) Handles DateTimePicker1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox5_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox5.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox6_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox6.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox7_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox7.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox8_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox8.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox3.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox9_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox9.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox2.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs) Handles TextBox10.TextChanged

    End Sub
End Class