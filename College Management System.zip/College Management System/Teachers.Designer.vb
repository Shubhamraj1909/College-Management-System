﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Teachers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Teachers))
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.DepartmentsCb = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TAddressTb = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TMobileNoTb = New System.Windows.Forms.TextBox()
        Me.TDOB = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TGenderCb = New System.Windows.Forms.ComboBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GunaCirclePictureBox1 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.LogoutPicture = New System.Windows.Forms.PictureBox()
        Me.DashboardLabel = New System.Windows.Forms.Label()
        Me.FeesLabel = New System.Windows.Forms.Label()
        Me.StudentsLabel = New System.Windows.Forms.Label()
        Me.TeachersLabel = New System.Windows.Forms.Label()
        Me.DashboardPicture = New System.Windows.Forms.PictureBox()
        Me.FeesPicture = New System.Windows.Forms.PictureBox()
        Me.StudentsPicture = New System.Windows.Forms.PictureBox()
        Me.TeachersPicture = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TeachersDGV = New Guna.UI.WinForms.GunaDataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TNameTb = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnReload = New System.Windows.Forms.Button()
        Me.TSearchTb = New System.Windows.Forms.TextBox()
        Me.TbtnSearch = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TeachersDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DepartmentsCb
        '
        Me.DepartmentsCb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DepartmentsCb.FormattingEnabled = True
        Me.DepartmentsCb.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.DepartmentsCb.Location = New System.Drawing.Point(495, 222)
        Me.DepartmentsCb.Name = "DepartmentsCb"
        Me.DepartmentsCb.Size = New System.Drawing.Size(151, 27)
        Me.DepartmentsCb.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(494, 196)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(134, 23)
        Me.Label5.TabIndex = 57
        Me.Label5.Text = "Departments"
        '
        'TAddressTb
        '
        Me.TAddressTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TAddressTb.Location = New System.Drawing.Point(687, 222)
        Me.TAddressTb.MaxLength = 25
        Me.TAddressTb.Name = "TAddressTb"
        Me.TAddressTb.Size = New System.Drawing.Size(150, 27)
        Me.TAddressTb.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(683, 191)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 23)
        Me.Label4.TabIndex = 55
        Me.Label4.Text = "Address"
        '
        'TMobileNoTb
        '
        Me.TMobileNoTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TMobileNoTb.Location = New System.Drawing.Point(900, 137)
        Me.TMobileNoTb.MaxLength = 10
        Me.TMobileNoTb.Name = "TMobileNoTb"
        Me.TMobileNoTb.Size = New System.Drawing.Size(146, 27)
        Me.TMobileNoTb.TabIndex = 3
        '
        'TDOB
        '
        Me.TDOB.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TDOB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.TDOB.Location = New System.Drawing.Point(705, 134)
        Me.TDOB.Name = "TDOB"
        Me.TDOB.Size = New System.Drawing.Size(149, 27)
        Me.TDOB.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(701, 105)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 23)
        Me.Label3.TabIndex = 52
        Me.Label3.Text = "D.O.B"
        '
        'TGenderCb
        '
        Me.TGenderCb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TGenderCb.FormattingEnabled = True
        Me.TGenderCb.Items.AddRange(New Object() {"Male", "Female", "Other"})
        Me.TGenderCb.Location = New System.Drawing.Point(532, 137)
        Me.TGenderCb.Name = "TGenderCb"
        Me.TGenderCb.Size = New System.Drawing.Size(121, 27)
        Me.TGenderCb.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.btnClose)
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(225, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(900, 80)
        Me.Panel3.TabIndex = 40
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(643, -2)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(76, 79)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Transparent
        Me.btnClose.Image = CType(resources.GetObject("btnClose.Image"), System.Drawing.Image)
        Me.btnClose.Location = New System.Drawing.Point(814, -4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(86, 84)
        Me.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnClose.TabIndex = 5
        Me.btnClose.TabStop = False
        Me.btnClose.UseWaitCursor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(74, 80)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Purple
        Me.Panel1.Controls.Add(Me.GunaCirclePictureBox1)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.PictureBox10)
        Me.Panel1.Controls.Add(Me.PictureBox9)
        Me.Panel1.Controls.Add(Me.LogoutPicture)
        Me.Panel1.Controls.Add(Me.DashboardLabel)
        Me.Panel1.Controls.Add(Me.FeesLabel)
        Me.Panel1.Controls.Add(Me.StudentsLabel)
        Me.Panel1.Controls.Add(Me.TeachersLabel)
        Me.Panel1.Controls.Add(Me.DashboardPicture)
        Me.Panel1.Controls.Add(Me.FeesPicture)
        Me.Panel1.Controls.Add(Me.StudentsPicture)
        Me.Panel1.Controls.Add(Me.TeachersPicture)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(225, 659)
        Me.Panel1.TabIndex = 39
        '
        'GunaCirclePictureBox1
        '
        Me.GunaCirclePictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaCirclePictureBox1.Image = Global.College_Management_System.My.Resources.Resources.images3
        Me.GunaCirclePictureBox1.Location = New System.Drawing.Point(3, 170)
        Me.GunaCirclePictureBox1.Name = "GunaCirclePictureBox1"
        Me.GunaCirclePictureBox1.Size = New System.Drawing.Size(82, 79)
        Me.GunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox1.TabIndex = 61
        Me.GunaCirclePictureBox1.TabStop = False
        Me.GunaCirclePictureBox1.UseTransfarantBackground = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(97, 549)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(71, 23)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Events"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(88, 454)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(126, 23)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Attendance"
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(0, 514)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(84, 79)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 18
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(0, 429)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(84, 79)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 17
        Me.PictureBox9.TabStop = False
        '
        'LogoutPicture
        '
        Me.LogoutPicture.Image = CType(resources.GetObject("LogoutPicture.Image"), System.Drawing.Image)
        Me.LogoutPicture.Location = New System.Drawing.Point(0, 609)
        Me.LogoutPicture.Name = "LogoutPicture"
        Me.LogoutPicture.Size = New System.Drawing.Size(66, 47)
        Me.LogoutPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.LogoutPicture.TabIndex = 12
        Me.LogoutPicture.TabStop = False
        '
        'DashboardLabel
        '
        Me.DashboardLabel.AutoSize = True
        Me.DashboardLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DashboardLabel.ForeColor = System.Drawing.Color.White
        Me.DashboardLabel.Location = New System.Drawing.Point(97, 358)
        Me.DashboardLabel.Name = "DashboardLabel"
        Me.DashboardLabel.Size = New System.Drawing.Size(116, 23)
        Me.DashboardLabel.TabIndex = 11
        Me.DashboardLabel.Text = "Dashboard"
        '
        'FeesLabel
        '
        Me.FeesLabel.AutoSize = True
        Me.FeesLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FeesLabel.ForeColor = System.Drawing.Color.White
        Me.FeesLabel.Location = New System.Drawing.Point(88, 280)
        Me.FeesLabel.Name = "FeesLabel"
        Me.FeesLabel.Size = New System.Drawing.Size(134, 23)
        Me.FeesLabel.TabIndex = 10
        Me.FeesLabel.Text = "Fees Deposit"
        '
        'StudentsLabel
        '
        Me.StudentsLabel.AutoSize = True
        Me.StudentsLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsLabel.ForeColor = System.Drawing.Color.White
        Me.StudentsLabel.Location = New System.Drawing.Point(88, 191)
        Me.StudentsLabel.Name = "StudentsLabel"
        Me.StudentsLabel.Size = New System.Drawing.Size(134, 23)
        Me.StudentsLabel.TabIndex = 9
        Me.StudentsLabel.Text = "Departments"
        '
        'TeachersLabel
        '
        Me.TeachersLabel.AutoSize = True
        Me.TeachersLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TeachersLabel.ForeColor = System.Drawing.Color.White
        Me.TeachersLabel.Location = New System.Drawing.Point(97, 110)
        Me.TeachersLabel.Name = "TeachersLabel"
        Me.TeachersLabel.Size = New System.Drawing.Size(91, 23)
        Me.TeachersLabel.TabIndex = 8
        Me.TeachersLabel.Text = "Students"
        '
        'DashboardPicture
        '
        Me.DashboardPicture.Image = CType(resources.GetObject("DashboardPicture.Image"), System.Drawing.Image)
        Me.DashboardPicture.Location = New System.Drawing.Point(-2, 340)
        Me.DashboardPicture.Name = "DashboardPicture"
        Me.DashboardPicture.Size = New System.Drawing.Size(84, 79)
        Me.DashboardPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DashboardPicture.TabIndex = 7
        Me.DashboardPicture.TabStop = False
        '
        'FeesPicture
        '
        Me.FeesPicture.Image = CType(resources.GetObject("FeesPicture.Image"), System.Drawing.Image)
        Me.FeesPicture.Location = New System.Drawing.Point(0, 255)
        Me.FeesPicture.Name = "FeesPicture"
        Me.FeesPicture.Size = New System.Drawing.Size(82, 79)
        Me.FeesPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FeesPicture.TabIndex = 6
        Me.FeesPicture.TabStop = False
        '
        'StudentsPicture
        '
        Me.StudentsPicture.Image = CType(resources.GetObject("StudentsPicture.Image"), System.Drawing.Image)
        Me.StudentsPicture.Location = New System.Drawing.Point(0, 170)
        Me.StudentsPicture.Name = "StudentsPicture"
        Me.StudentsPicture.Size = New System.Drawing.Size(82, 79)
        Me.StudentsPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.StudentsPicture.TabIndex = 5
        Me.StudentsPicture.TabStop = False
        '
        'TeachersPicture
        '
        Me.TeachersPicture.Image = Global.College_Management_System.My.Resources.Resources.Student_3_icon
        Me.TeachersPicture.Location = New System.Drawing.Point(0, 85)
        Me.TeachersPicture.Name = "TeachersPicture"
        Me.TeachersPicture.Size = New System.Drawing.Size(82, 79)
        Me.TeachersPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.TeachersPicture.TabIndex = 4
        Me.TeachersPicture.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Location = New System.Drawing.Point(0, -4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(245, 84)
        Me.Panel2.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(82, 79)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'TeachersDGV
        '
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.White
        Me.TeachersDGV.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle10
        Me.TeachersDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.TeachersDGV.BackgroundColor = System.Drawing.Color.White
        Me.TeachersDGV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TeachersDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.TeachersDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.Purple
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.TeachersDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.TeachersDGV.ColumnHeadersHeight = 25
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.TeachersDGV.DefaultCellStyle = DataGridViewCellStyle12
        Me.TeachersDGV.EnableHeadersVisualStyles = False
        Me.TeachersDGV.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TeachersDGV.Location = New System.Drawing.Point(259, 359)
        Me.TeachersDGV.Name = "TeachersDGV"
        Me.TeachersDGV.RowHeadersVisible = False
        Me.TeachersDGV.RowHeadersWidth = 62
        Me.TeachersDGV.RowTemplate.Height = 28
        Me.TeachersDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.TeachersDGV.Size = New System.Drawing.Size(824, 234)
        Me.TeachersDGV.TabIndex = 50
        Me.TeachersDGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna
        Me.TeachersDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.TeachersDGV.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.TeachersDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.TeachersDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.TeachersDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.TeachersDGV.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.TeachersDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TeachersDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Purple
        Me.TeachersDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.TeachersDGV.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TeachersDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.TeachersDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.TeachersDGV.ThemeStyle.HeaderStyle.Height = 25
        Me.TeachersDGV.ThemeStyle.ReadOnly = False
        Me.TeachersDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White
        Me.TeachersDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.TeachersDGV.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TeachersDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.TeachersDGV.ThemeStyle.RowsStyle.Height = 28
        Me.TeachersDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TeachersDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(597, 328)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(169, 28)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "Teachers Lists"
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.Color.DarkOrange
        Me.btnReset.FlatAppearance.BorderSize = 0
        Me.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReset.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.White
        Me.btnReset.Location = New System.Drawing.Point(888, 267)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(133, 49)
        Me.btnReset.TabIndex = 9
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.DarkOrange
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(705, 267)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(119, 49)
        Me.btnDelete.TabIndex = 8
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.DarkOrange
        Me.btnUpdate.FlatAppearance.BorderSize = 0
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.Location = New System.Drawing.Point(505, 267)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(123, 49)
        Me.btnUpdate.TabIndex = 7
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.Color.DarkOrange
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(317, 267)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(117, 49)
        Me.btnSave.TabIndex = 6
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(896, 110)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(111, 23)
        Me.Label8.TabIndex = 44
        Me.Label8.Text = "Mobile No"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(528, 110)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 23)
        Me.Label7.TabIndex = 43
        Me.Label7.Text = "Gender"
        '
        'TNameTb
        '
        Me.TNameTb.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TNameTb.Location = New System.Drawing.Point(327, 140)
        Me.TNameTb.MaxLength = 20
        Me.TNameTb.Name = "TNameTb"
        Me.TNameTb.Size = New System.Drawing.Size(155, 27)
        Me.TNameTb.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(323, 110)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(167, 23)
        Me.Label6.TabIndex = 41
        Me.Label6.Text = "Teacher's Name"
        '
        'btnReload
        '
        Me.btnReload.BackColor = System.Drawing.Color.DarkOrange
        Me.btnReload.FlatAppearance.BorderSize = 0
        Me.btnReload.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReload.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReload.ForeColor = System.Drawing.Color.White
        Me.btnReload.Location = New System.Drawing.Point(346, 599)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(119, 48)
        Me.btnReload.TabIndex = 58
        Me.btnReload.Text = "Reload"
        Me.btnReload.UseVisualStyleBackColor = False
        '
        'TSearchTb
        '
        Me.TSearchTb.Location = New System.Drawing.Point(544, 609)
        Me.TSearchTb.MaxLength = 3
        Me.TSearchTb.Name = "TSearchTb"
        Me.TSearchTb.Size = New System.Drawing.Size(119, 32)
        Me.TSearchTb.TabIndex = 59
        '
        'TbtnSearch
        '
        Me.TbtnSearch.BackColor = System.Drawing.Color.DarkOrange
        Me.TbtnSearch.FlatAppearance.BorderSize = 0
        Me.TbtnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.TbtnSearch.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbtnSearch.ForeColor = System.Drawing.Color.White
        Me.TbtnSearch.Location = New System.Drawing.Point(679, 599)
        Me.TbtnSearch.Name = "TbtnSearch"
        Me.TbtnSearch.Size = New System.Drawing.Size(117, 48)
        Me.TbtnSearch.TabIndex = 60
        Me.TbtnSearch.Text = "Search"
        Me.TbtnSearch.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Wide Latin", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(263, 23)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(240, 34)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Teachers"
        '
        'Teachers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1125, 659)
        Me.Controls.Add(Me.TbtnSearch)
        Me.Controls.Add(Me.TSearchTb)
        Me.Controls.Add(Me.btnReload)
        Me.Controls.Add(Me.DepartmentsCb)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TAddressTb)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TMobileNoTb)
        Me.Controls.Add(Me.TDOB)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TGenderCb)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TeachersDGV)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TNameTb)
        Me.Controls.Add(Me.Label6)
        Me.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "Teachers"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Teachers"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TeachersDGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DepartmentsCb As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TAddressTb As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TMobileNoTb As TextBox
    Friend WithEvents TDOB As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents TGenderCb As ComboBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnClose As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents LogoutPicture As PictureBox
    Friend WithEvents DashboardLabel As Label
    Friend WithEvents FeesLabel As Label
    Friend WithEvents StudentsLabel As Label
    Friend WithEvents TeachersLabel As Label
    Friend WithEvents DashboardPicture As PictureBox
    Friend WithEvents FeesPicture As PictureBox
    Friend WithEvents StudentsPicture As PictureBox
    Friend WithEvents TeachersPicture As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TeachersDGV As Guna.UI.WinForms.GunaDataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents btnReset As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents TNameTb As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnReload As Button
    Friend WithEvents TSearchTb As TextBox
    Friend WithEvents TbtnSearch As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents GunaCirclePictureBox1 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents Label9 As Label
End Class
