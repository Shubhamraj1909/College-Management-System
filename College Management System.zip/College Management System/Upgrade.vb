﻿Imports System.Data.SqlClient

Public Class Upgrade
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub Upgrade_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        If UpgradeFromCb.Text = "" Or UpgradeToCb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "update StudentsTbl set StSemester = '" & UpgradeToCb.Text & "' where StSemester= '" & UpgradeFromCb.Text & "'"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Semester Upgraded Successfully")
                Con.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub
End Class