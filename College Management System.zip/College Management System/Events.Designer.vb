﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Events
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Events))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GunaCirclePictureBox1 = New Guna.UI.WinForms.GunaCirclePictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.LogoutPicture = New System.Windows.Forms.PictureBox()
        Me.DashboardLabel = New System.Windows.Forms.Label()
        Me.FeesLabel = New System.Windows.Forms.Label()
        Me.StudentsLabel = New System.Windows.Forms.Label()
        Me.TeachersLabel = New System.Windows.Forms.Label()
        Me.DashboardPicture = New System.Windows.Forms.PictureBox()
        Me.FeesPicture = New System.Windows.Forms.PictureBox()
        Me.StudentsPicture = New System.Windows.Forms.PictureBox()
        Me.TeachersPicture = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ENameTb = New System.Windows.Forms.TextBox()
        Me.EDateDtp = New System.Windows.Forms.DateTimePicker()
        Me.EDurationTb = New System.Windows.Forms.TextBox()
        Me.EAddressTb = New System.Windows.Forms.TextBox()
        Me.btnEReset = New System.Windows.Forms.Button()
        Me.btnEDelete = New System.Windows.Forms.Button()
        Me.btnEUpdate = New System.Windows.Forms.Button()
        Me.btnESave = New System.Windows.Forms.Button()
        Me.EventDGV = New Guna.UI.WinForms.GunaDataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.StbtnSearch = New System.Windows.Forms.Button()
        Me.StSearchTb = New System.Windows.Forms.TextBox()
        Me.btnReload = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EventDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Purple
        Me.Panel1.Controls.Add(Me.GunaCirclePictureBox1)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.PictureBox10)
        Me.Panel1.Controls.Add(Me.PictureBox9)
        Me.Panel1.Controls.Add(Me.LogoutPicture)
        Me.Panel1.Controls.Add(Me.DashboardLabel)
        Me.Panel1.Controls.Add(Me.FeesLabel)
        Me.Panel1.Controls.Add(Me.StudentsLabel)
        Me.Panel1.Controls.Add(Me.TeachersLabel)
        Me.Panel1.Controls.Add(Me.DashboardPicture)
        Me.Panel1.Controls.Add(Me.FeesPicture)
        Me.Panel1.Controls.Add(Me.StudentsPicture)
        Me.Panel1.Controls.Add(Me.TeachersPicture)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(211, 622)
        Me.Panel1.TabIndex = 77
        '
        'GunaCirclePictureBox1
        '
        Me.GunaCirclePictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaCirclePictureBox1.Image = Global.College_Management_System.My.Resources.Resources.images3
        Me.GunaCirclePictureBox1.Location = New System.Drawing.Point(1, 154)
        Me.GunaCirclePictureBox1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.GunaCirclePictureBox1.Name = "GunaCirclePictureBox1"
        Me.GunaCirclePictureBox1.Size = New System.Drawing.Size(65, 71)
        Me.GunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaCirclePictureBox1.TabIndex = 94
        Me.GunaCirclePictureBox1.TabStop = False
        Me.GunaCirclePictureBox1.UseTransfarantBackground = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(70, 493)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(126, 23)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "Attendance"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(70, 407)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(104, 23)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "Dasboard"
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(0, 461)
        Me.PictureBox10.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(67, 71)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 14
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(0, 385)
        Me.PictureBox9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(67, 71)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 13
        Me.PictureBox9.TabStop = False
        '
        'LogoutPicture
        '
        Me.LogoutPicture.Image = CType(resources.GetObject("LogoutPicture.Image"), System.Drawing.Image)
        Me.LogoutPicture.Location = New System.Drawing.Point(2, 556)
        Me.LogoutPicture.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.LogoutPicture.Name = "LogoutPicture"
        Me.LogoutPicture.Size = New System.Drawing.Size(53, 62)
        Me.LogoutPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.LogoutPicture.TabIndex = 12
        Me.LogoutPicture.TabStop = False
        '
        'DashboardLabel
        '
        Me.DashboardLabel.AutoSize = True
        Me.DashboardLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DashboardLabel.ForeColor = System.Drawing.Color.White
        Me.DashboardLabel.Location = New System.Drawing.Point(70, 329)
        Me.DashboardLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DashboardLabel.Name = "DashboardLabel"
        Me.DashboardLabel.Size = New System.Drawing.Size(134, 23)
        Me.DashboardLabel.TabIndex = 3
        Me.DashboardLabel.Text = "Fees Deposit"
        '
        'FeesLabel
        '
        Me.FeesLabel.AutoSize = True
        Me.FeesLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FeesLabel.ForeColor = System.Drawing.Color.White
        Me.FeesLabel.Location = New System.Drawing.Point(70, 253)
        Me.FeesLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.FeesLabel.Name = "FeesLabel"
        Me.FeesLabel.Size = New System.Drawing.Size(97, 23)
        Me.FeesLabel.TabIndex = 2
        Me.FeesLabel.Text = "Teachers"
        '
        'StudentsLabel
        '
        Me.StudentsLabel.AutoSize = True
        Me.StudentsLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentsLabel.ForeColor = System.Drawing.Color.White
        Me.StudentsLabel.Location = New System.Drawing.Point(70, 173)
        Me.StudentsLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.StudentsLabel.Name = "StudentsLabel"
        Me.StudentsLabel.Size = New System.Drawing.Size(134, 23)
        Me.StudentsLabel.TabIndex = 1
        Me.StudentsLabel.Text = "Departments"
        '
        'TeachersLabel
        '
        Me.TeachersLabel.AutoSize = True
        Me.TeachersLabel.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TeachersLabel.ForeColor = System.Drawing.Color.White
        Me.TeachersLabel.Location = New System.Drawing.Point(77, 100)
        Me.TeachersLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TeachersLabel.Name = "TeachersLabel"
        Me.TeachersLabel.Size = New System.Drawing.Size(91, 23)
        Me.TeachersLabel.TabIndex = 0
        Me.TeachersLabel.Text = "Students"
        '
        'DashboardPicture
        '
        Me.DashboardPicture.Image = CType(resources.GetObject("DashboardPicture.Image"), System.Drawing.Image)
        Me.DashboardPicture.Location = New System.Drawing.Point(-1, 308)
        Me.DashboardPicture.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.DashboardPicture.Name = "DashboardPicture"
        Me.DashboardPicture.Size = New System.Drawing.Size(67, 71)
        Me.DashboardPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DashboardPicture.TabIndex = 7
        Me.DashboardPicture.TabStop = False
        '
        'FeesPicture
        '
        Me.FeesPicture.Image = CType(resources.GetObject("FeesPicture.Image"), System.Drawing.Image)
        Me.FeesPicture.Location = New System.Drawing.Point(0, 230)
        Me.FeesPicture.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.FeesPicture.Name = "FeesPicture"
        Me.FeesPicture.Size = New System.Drawing.Size(65, 71)
        Me.FeesPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FeesPicture.TabIndex = 6
        Me.FeesPicture.TabStop = False
        '
        'StudentsPicture
        '
        Me.StudentsPicture.Image = CType(resources.GetObject("StudentsPicture.Image"), System.Drawing.Image)
        Me.StudentsPicture.Location = New System.Drawing.Point(0, 154)
        Me.StudentsPicture.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.StudentsPicture.Name = "StudentsPicture"
        Me.StudentsPicture.Size = New System.Drawing.Size(65, 71)
        Me.StudentsPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.StudentsPicture.TabIndex = 5
        Me.StudentsPicture.TabStop = False
        '
        'TeachersPicture
        '
        Me.TeachersPicture.Image = CType(resources.GetObject("TeachersPicture.Image"), System.Drawing.Image)
        Me.TeachersPicture.Location = New System.Drawing.Point(0, 78)
        Me.TeachersPicture.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.TeachersPicture.Name = "TeachersPicture"
        Me.TeachersPicture.Size = New System.Drawing.Size(65, 71)
        Me.TeachersPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.TeachersPicture.TabIndex = 4
        Me.TeachersPicture.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.MediumPurple
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Location = New System.Drawing.Point(0, -4)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(211, 76)
        Me.Panel2.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 4)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(65, 71)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.MediumPurple
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.btnClose)
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(211, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(759, 72)
        Me.Panel3.TabIndex = 78
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(543, 1)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(59, 71)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Transparent
        Me.btnClose.Image = CType(resources.GetObject("btnClose.Image"), System.Drawing.Image)
        Me.btnClose.Location = New System.Drawing.Point(684, 0)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(73, 73)
        Me.btnClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnClose.TabIndex = 5
        Me.btnClose.TabStop = False
        Me.btnClose.UseWaitCursor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(2, 1)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(77, 72)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(216, 110)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 23)
        Me.Label2.TabIndex = 79
        Me.Label2.Text = "Event Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(458, 110)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(114, 23)
        Me.Label3.TabIndex = 80
        Me.Label3.Text = "Event Date"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(711, 110)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(149, 23)
        Me.Label4.TabIndex = 81
        Me.Label4.Text = "Event Duration"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(217, 154)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(126, 23)
        Me.Label5.TabIndex = 82
        Me.Label5.Text = "Full Address"
        '
        'ENameTb
        '
        Me.ENameTb.Location = New System.Drawing.Point(348, 111)
        Me.ENameTb.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ENameTb.MaxLength = 20
        Me.ENameTb.Name = "ENameTb"
        Me.ENameTb.Size = New System.Drawing.Size(95, 25)
        Me.ENameTb.TabIndex = 83
        '
        'EDateDtp
        '
        Me.EDateDtp.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.EDateDtp.Location = New System.Drawing.Point(576, 108)
        Me.EDateDtp.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.EDateDtp.Name = "EDateDtp"
        Me.EDateDtp.Size = New System.Drawing.Size(131, 25)
        Me.EDateDtp.TabIndex = 84
        '
        'EDurationTb
        '
        Me.EDurationTb.Location = New System.Drawing.Point(864, 110)
        Me.EDurationTb.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.EDurationTb.MaxLength = 1
        Me.EDurationTb.Name = "EDurationTb"
        Me.EDurationTb.Size = New System.Drawing.Size(95, 25)
        Me.EDurationTb.TabIndex = 85
        '
        'EAddressTb
        '
        Me.EAddressTb.Location = New System.Drawing.Point(341, 154)
        Me.EAddressTb.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.EAddressTb.MaxLength = 50
        Me.EAddressTb.Name = "EAddressTb"
        Me.EAddressTb.Size = New System.Drawing.Size(588, 25)
        Me.EAddressTb.TabIndex = 86
        '
        'btnEReset
        '
        Me.btnEReset.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEReset.ForeColor = System.Drawing.Color.White
        Me.btnEReset.Location = New System.Drawing.Point(701, 215)
        Me.btnEReset.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.btnEReset.Name = "btnEReset"
        Me.btnEReset.Size = New System.Drawing.Size(98, 46)
        Me.btnEReset.TabIndex = 95
        Me.btnEReset.Text = "Reset"
        Me.btnEReset.UseVisualStyleBackColor = False
        '
        'btnEDelete
        '
        Me.btnEDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEDelete.ForeColor = System.Drawing.Color.White
        Me.btnEDelete.Location = New System.Drawing.Point(577, 215)
        Me.btnEDelete.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.btnEDelete.Name = "btnEDelete"
        Me.btnEDelete.Size = New System.Drawing.Size(94, 46)
        Me.btnEDelete.TabIndex = 94
        Me.btnEDelete.Text = "Delete"
        Me.btnEDelete.UseVisualStyleBackColor = False
        '
        'btnEUpdate
        '
        Me.btnEUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnEUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEUpdate.ForeColor = System.Drawing.Color.White
        Me.btnEUpdate.Location = New System.Drawing.Point(440, 215)
        Me.btnEUpdate.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.btnEUpdate.Name = "btnEUpdate"
        Me.btnEUpdate.Size = New System.Drawing.Size(89, 46)
        Me.btnEUpdate.TabIndex = 93
        Me.btnEUpdate.Text = "Update"
        Me.btnEUpdate.UseVisualStyleBackColor = False
        '
        'btnESave
        '
        Me.btnESave.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnESave.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnESave.ForeColor = System.Drawing.Color.White
        Me.btnESave.Location = New System.Drawing.Point(312, 215)
        Me.btnESave.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.btnESave.Name = "btnESave"
        Me.btnESave.Size = New System.Drawing.Size(96, 46)
        Me.btnESave.TabIndex = 92
        Me.btnESave.Text = "Save"
        Me.btnESave.UseVisualStyleBackColor = False
        '
        'EventDGV
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.EventDGV.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.EventDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.EventDGV.BackgroundColor = System.Drawing.Color.White
        Me.EventDGV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.EventDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.EventDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.EventDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.EventDGV.ColumnHeadersHeight = 30
        Me.EventDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.EventDGV.DefaultCellStyle = DataGridViewCellStyle3
        Me.EventDGV.EnableHeadersVisualStyles = False
        Me.EventDGV.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.EventDGV.Location = New System.Drawing.Point(248, 385)
        Me.EventDGV.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.EventDGV.Name = "EventDGV"
        Me.EventDGV.ReadOnly = True
        Me.EventDGV.RowHeadersVisible = False
        Me.EventDGV.RowHeadersWidth = 62
        Me.EventDGV.RowTemplate.Height = 28
        Me.EventDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.EventDGV.Size = New System.Drawing.Size(695, 205)
        Me.EventDGV.TabIndex = 96
        Me.EventDGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna
        Me.EventDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White
        Me.EventDGV.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.EventDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.EventDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.EventDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.EventDGV.ThemeStyle.BackColor = System.Drawing.Color.White
        Me.EventDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.EventDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.EventDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.EventDGV.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EventDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.EventDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.EventDGV.ThemeStyle.HeaderStyle.Height = 30
        Me.EventDGV.ThemeStyle.ReadOnly = True
        Me.EventDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White
        Me.EventDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.EventDGV.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Century Gothic", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EventDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.EventDGV.ThemeStyle.RowsStyle.Height = 28
        Me.EventDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.EventDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(94, Byte), Integer))
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(474, 329)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 34)
        Me.Label6.TabIndex = 97
        Me.Label6.Text = "Event List"
        '
        'StbtnSearch
        '
        Me.StbtnSearch.BackColor = System.Drawing.Color.DarkOrange
        Me.StbtnSearch.FlatAppearance.BorderSize = 0
        Me.StbtnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.StbtnSearch.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StbtnSearch.ForeColor = System.Drawing.Color.White
        Me.StbtnSearch.Location = New System.Drawing.Point(817, 293)
        Me.StbtnSearch.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StbtnSearch.Name = "StbtnSearch"
        Me.StbtnSearch.Size = New System.Drawing.Size(93, 43)
        Me.StbtnSearch.TabIndex = 100
        Me.StbtnSearch.Text = "Search"
        Me.StbtnSearch.UseVisualStyleBackColor = False
        '
        'StSearchTb
        '
        Me.StSearchTb.Location = New System.Drawing.Point(681, 302)
        Me.StSearchTb.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.StSearchTb.MaxLength = 3
        Me.StSearchTb.Name = "StSearchTb"
        Me.StSearchTb.Size = New System.Drawing.Size(121, 25)
        Me.StSearchTb.TabIndex = 99
        '
        'btnReload
        '
        Me.btnReload.BackColor = System.Drawing.Color.DarkOrange
        Me.btnReload.FlatAppearance.BorderSize = 0
        Me.btnReload.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReload.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReload.ForeColor = System.Drawing.Color.White
        Me.btnReload.Location = New System.Drawing.Point(833, 218)
        Me.btnReload.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(95, 43)
        Me.btnReload.TabIndex = 98
        Me.btnReload.Text = "Reload"
        Me.btnReload.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Wide Latin", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(191, 17)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(190, 34)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Events"
        '
        'Events
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(970, 622)
        Me.Controls.Add(Me.StbtnSearch)
        Me.Controls.Add(Me.StSearchTb)
        Me.Controls.Add(Me.btnReload)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.EventDGV)
        Me.Controls.Add(Me.btnEReset)
        Me.Controls.Add(Me.btnEDelete)
        Me.Controls.Add(Me.btnEUpdate)
        Me.Controls.Add(Me.btnESave)
        Me.Controls.Add(Me.EAddressTb)
        Me.Controls.Add(Me.EDurationTb)
        Me.Controls.Add(Me.EDateDtp)
        Me.Controls.Add(Me.ENameTb)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Century Gothic", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Events"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Events"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.GunaCirclePictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LogoutPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DashboardPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FeesPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TeachersPicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EventDGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents GunaCirclePictureBox1 As Guna.UI.WinForms.GunaCirclePictureBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents LogoutPicture As PictureBox
    Friend WithEvents DashboardLabel As Label
    Friend WithEvents FeesLabel As Label
    Friend WithEvents StudentsLabel As Label
    Friend WithEvents TeachersLabel As Label
    Friend WithEvents DashboardPicture As PictureBox
    Friend WithEvents FeesPicture As PictureBox
    Friend WithEvents StudentsPicture As PictureBox
    Friend WithEvents TeachersPicture As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnClose As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents ENameTb As TextBox
    Friend WithEvents EDateDtp As DateTimePicker
    Friend WithEvents EDurationTb As TextBox
    Friend WithEvents EAddressTb As TextBox
    Friend WithEvents btnEReset As Button
    Friend WithEvents btnEDelete As Button
    Friend WithEvents btnEUpdate As Button
    Friend WithEvents btnESave As Button
    Friend WithEvents EventDGV As Guna.UI.WinForms.GunaDataGridView
    Friend WithEvents Label6 As Label
    Friend WithEvents StbtnSearch As Button
    Friend WithEvents StSearchTb As TextBox
    Friend WithEvents btnReload As Button
    Friend WithEvents Label9 As Label
End Class
