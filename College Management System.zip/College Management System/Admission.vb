﻿Imports System.Data.SqlClient
Imports System.Text.RegularExpressions
Public Class Admission
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub Displayenquiry()
        Con.Open()
        Dim query = "select * from AdmissionTbl "
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        Con.Close()


    End Sub
    Private Sub Reset()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        ComboBox4.Text = ""
        ComboBox5.Text = ""
        ComboBox6.Text = ""
        ComboBox7.Text = ""
        ComboBox8.Text = ""
        ComboBox9.Text = ""
        ComboBox10.Text = ""
        ComboBox11.Text = ""
        DateTimePicker1.ResetText()
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
        TextBox10.Text = ""
        TextBox11.Text = ""
        TextBox12.Text = ""
        TextBox13.Text = ""
        TextBox14.Text = ""
        TextBox15.Text = ""
        TextBox16.Text = ""
        TextBox17.Text = ""


    End Sub

    Private Sub Admission_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Displayenquiry()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.Text = "" Or ComboBox2.Text = "" Or
                 ComboBox3.Text = "" Or ComboBox4.Text = "" Or ComboBox5.Text = "" Or
            ComboBox6.Text = "" Or ComboBox7.Text = "" Or ComboBox8.Text = "" Or ComboBox9.Text = "" Or ComboBox10.Text = "" Or ComboBox11.Text = "" Or
            TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Or TextBox10.Text = "" Or TextBox11.Text = "" Or TextBox12.Text = "" Or TextBox13.Text = "" Or TextBox14.Text = "" Or TextBox15.Text = "" Or
  TextBox16.Text = "" Then

            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "insert into AdmissionTbl values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox1.Text.ToString() & "','" & TextBox4.Text & "','" & ComboBox2.Text.ToString() & "','" & ComboBox3.Text.ToString() & "','" & DateTimePicker1.Value.Date & "','" & ComboBox4.Text.ToString() & "','" & TextBox5.Text & "',
'" & TextBox6.Text & "','" & ComboBox5.Text.ToString() & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" & TextBox10.Text & "','" & TextBox11.Text & "','" & TextBox12.Text & "','" & TextBox13.Text & "','" & TextBox14.Text & "','" & ComboBox6.Text.ToString() & "','" & ComboBox7.Text.ToString() & "','" & ComboBox8.Text.ToString() & "','" & TextBox15.Text & "','" & TextBox16.Text & "','" & ComboBox9.Text.ToString() & "','" & ComboBox10.Text.ToString() & "','" & ComboBox11.Text.ToString() & "')"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student saved Successfully")
                Con.Close()
                Displayenquiry()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            '            Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.SelectedIndex = -1 Or ComboBox2.SelectedIndex = -1 Or
            '              ComboBox3.SelectedIndex = -1 Or ComboBox4.SelectedIndex = -1 Or ComboBox5.SelectedIndex = -1 Or
            '         ComboBox6.SelectedIndex = -1 Or ComboBox7.SelectedIndex = -1 Or ComboBox8.SelectedIndex = -1 Or ComboBox9.SelectedIndex = -1 Or ComboBox10.SelectedIndex = -1 Or ComboBox11.SelectedIndex = -1 Or
            '         TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Or TextBox10.Text = "" Or TextBox11.Text = "" Or TextBox12.Text = "" Or TextBox13.Text = "" Or TextBox14.Text = "" Or TextBox15.Text = "" Or
            'TextBox16.Text = ""

            MsgBox("Missing Information .... !")
        Else


            Try
                Con.Open()
                Dim query = "update AdmissionTbl set StName='" & TextBox2.Text & "',StFName='" & TextBox3.Text & "',StFatherOccupation='" & ComboBox1.Text.ToString() & "',StMName='" & TextBox4.Text & "',StMotherOccupation='" & ComboBox2.Text.ToString() & "',StGender='" & ComboBox3.Text.ToString() & "',StDOB='" & DateTimePicker1.Value.Date & "',StCategory='" & ComboBox4.Text.ToString() & "', StEmail='" & TextBox5.Text & "',StPhone='" & TextBox6.Text & "',StCourse='" & ComboBox5.Text.ToString() & "',StFatherPhone='" & TextBox7.Text & " ', Income= '" & TextBox8.Text & "', Address= '" & TextBox9.Text & "', Pincode= '" & TextBox10.Text & "', District= '" & TextBox11.Text & "',State= '" & TextBox12.Text & "', MatricSchool='" & TextBox13.Text & "', MatricParcentage='" & TextBox14.Text & "', MatricDivision='" & ComboBox6.Text.ToString() & "', MatricYear='" & ComboBox7.Text.ToString() & "', MatricBoard='" & ComboBox8.Text.ToString() & "', InterSchool='" & TextBox15.Text & "', InterPercentage='" & TextBox16.Text & "', InterDivision='" & ComboBox9.Text.ToString() & "', InterYear='" & ComboBox10.Text.ToString() & "', InterBoard='" & ComboBox11.Text.ToString() & "'where StId=" & key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student updated Successfully")
                Con.Close()
                Displayenquiry()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If key = 0 Then
            MsgBox("Please Select the Student to Delete")
        Else
            Try
                Con.Open()
                Dim query = "delete from AdmissionTbl where StId=" & key & ""

                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student Deleted Successfully")
                Con.Close()
                Displayenquiry()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Reset()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Displayenquiry()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim cmd As New SqlCommand("select * from AdmissionTbl where StId='" & TextBox17.Text & "'", Con)

        Dim sda As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        sda.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs)
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
        TextBox1.Text = row.Cells(0).Value.ToString
        TextBox2.Text = row.Cells(1).Value.ToString
        TextBox3.Text = row.Cells(2).Value.ToString
        ComboBox1.Text = row.Cells(3).Value.ToString
        TextBox4.Text = row.Cells(4).Value.ToString
        ComboBox2.Text = row.Cells(5).Value.ToString
        ComboBox3.Text = row.Cells(6).Value.ToString
        DateTimePicker1.Text = row.Cells(7).Value.ToString
        ComboBox4.Text = row.Cells(8).Value.ToString
        TextBox5.Text = row.Cells(9).Value.ToString
        TextBox6.Text = row.Cells(10).Value.ToString
        ComboBox5.Text = row.Cells(11).Value.ToString
        TextBox7.Text = row.Cells(12).Value.ToString
        TextBox8.Text = row.Cells(13).Value.ToString
        TextBox9.Text = row.Cells(14).Value.ToString
        TextBox10.Text = row.Cells(15).Value.ToString
        TextBox11.Text = row.Cells(16).Value.ToString
        TextBox12.Text = row.Cells(17).Value.ToString
        TextBox13.Text = row.Cells(18).Value.ToString
        TextBox14.Text = row.Cells(19).Value.ToString
        ComboBox6.Text = row.Cells(20).Value.ToString
        ComboBox7.Text = row.Cells(21).Value.ToString
        ComboBox8.Text = row.Cells(22).Value.ToString
        TextBox15.Text = row.Cells(23).Value.ToString
        TextBox16.Text = row.Cells(24).Value.ToString
        ComboBox9.Text = row.Cells(25).Value.ToString
        ComboBox10.Text = row.Cells(26).Value.ToString
        ComboBox11.Text = row.Cells(27).Value.ToString

        If TextBox2.Text = "" Then

            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim Obj = New Student_Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
    Dim key = 0
    Private Sub DataGridView1_CellMouseClick_1(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
        TextBox1.Text = row.Cells(0).Value.ToString
        TextBox2.Text = row.Cells(1).Value.ToString
        TextBox3.Text = row.Cells(2).Value.ToString
        ComboBox1.Text = row.Cells(3).Value.ToString
        TextBox4.Text = row.Cells(4).Value.ToString
        ComboBox2.Text = row.Cells(5).Value.ToString
        ComboBox3.Text = row.Cells(6).Value.ToString
        DateTimePicker1.Text = row.Cells(7).Value.ToString
        ComboBox4.Text = row.Cells(8).Value.ToString
        TextBox5.Text = row.Cells(9).Value.ToString
        TextBox6.Text = row.Cells(10).Value.ToString
        ComboBox5.Text = row.Cells(11).Value.ToString
        TextBox7.Text = row.Cells(12).Value.ToString
        TextBox8.Text = row.Cells(13).Value.ToString
        TextBox9.Text = row.Cells(14).Value.ToString
        TextBox10.Text = row.Cells(15).Value.ToString
        TextBox11.Text = row.Cells(16).Value.ToString
        TextBox12.Text = row.Cells(17).Value.ToString
        TextBox13.Text = row.Cells(18).Value.ToString
        TextBox14.Text = row.Cells(19).Value.ToString
        ComboBox6.Text = row.Cells(20).Value.ToString
        ComboBox7.Text = row.Cells(21).Value.ToString
        ComboBox8.Text = row.Cells(22).Value.ToString
        TextBox15.Text = row.Cells(23).Value.ToString
        TextBox16.Text = row.Cells(24).Value.ToString
        ComboBox9.Text = row.Cells(25).Value.ToString
        ComboBox10.Text = row.Cells(26).Value.ToString
        ComboBox11.Text = row.Cells(27).Value.ToString

        If TextBox2.Text = "" Then

            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If

    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox3.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox4_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox4.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox2.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox3.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub DateTimePicker1_KeyDown(sender As Object, e As KeyEventArgs) Handles DateTimePicker1.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox4_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox4.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox5_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox5.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox6_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox6.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox5_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox5.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox7_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox7.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox8_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox8.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox9_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox9.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox10_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox10.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox11_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox11.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox12_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox12.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox13_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox13.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox14_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox14.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox6_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox6.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox7_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox7.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox8_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox8.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox15_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox15.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox16_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox16.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox9_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox9.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox10_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox10.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub ComboBox11_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox11.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        '        If IsNumeric(TextBox1.Text) Then
        '            ErrorProvider1.SetError(TextBox1, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox1, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Id Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox1.Clear()
        '        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        'If Not IsNumeric(TextBox2.Text) Then


        '    ErrorProvider1.SetError(TextBox2, "")

        'Else
        '    ErrorProvider1.SetError(TextBox2, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox2.Clear()
        'End If
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        'If Not IsNumeric(TextBox3.Text) Then


        '    ErrorProvider1.SetError(TextBox3, "")

        'Else
        '    ErrorProvider1.SetError(TextBox3, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox3.Clear()
        'End If
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        'If Not IsNumeric(TextBox4.Text) Then


        '    ErrorProvider1.SetError(TextBox4, "")

        'Else
        '    ErrorProvider1.SetError(TextBox4, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox4.Clear()
        'End If
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        Dim regex As Regex = New Regex("^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
        Dim isValid As Boolean = regex.IsMatch(TextBox5.Text.Trim)
        If isValid Then
            ErrorProvider1.SetError(TextBox5, "")
            'MessageBox.Show("correct email")
        Else
            ErrorProvider1.SetError(TextBox5, "Invalid
Email Id:")
            'MessageBox.Show("invalid Email.")
        End If
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        '        If IsNumeric(TextBox6.Text) Then
        '            ErrorProvider1.SetError(TextBox6, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox6, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Mobile NUmber",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox6.Clear()
        '        End If
    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged
        '        If IsNumeric(TextBox7.Text) Then
        '            ErrorProvider1.SetError(TextBox7, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox7, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Mobile NUmber",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox7.Clear()
        '        End If
    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged
        '        If IsNumeric(TextBox8.Text) Then
        '            ErrorProvider1.SetError(TextBox8, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox8, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox8.Clear()
        '        End If
    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs) Handles TextBox9.TextChanged
        'If Not IsNumeric(TextBox9.Text) Then


        '    ErrorProvider1.SetError(TextBox9, "")

        'Else
        '    ErrorProvider1.SetError(TextBox9, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox9.Clear()
        'End If
    End Sub

    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs) Handles TextBox10.TextChanged
        '        If IsNumeric(TextBox10.Text) Then
        '            ErrorProvider1.SetError(TextBox10, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox10, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox10.Clear()
        '        End If
    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs) Handles TextBox11.TextChanged
        'If Not IsNumeric(TextBox11.Text) Then


        '    ErrorProvider1.SetError(TextBox11, "")

        'Else
        '    ErrorProvider1.SetError(TextBox11, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox11.Clear()
        'End If
    End Sub

    Private Sub TextBox12_TextChanged(sender As Object, e As EventArgs) Handles TextBox12.TextChanged
        'If Not IsNumeric(TextBox12.Text) Then


        '    ErrorProvider1.SetError(TextBox12, "")

        'Else
        '    ErrorProvider1.SetError(TextBox12, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox12.Clear()
        'End If
    End Sub

    Private Sub TextBox13_TextChanged(sender As Object, e As EventArgs) Handles TextBox13.TextChanged
        'If Not IsNumeric(TextBox13.Text) Then


        '    ErrorProvider1.SetError(TextBox13, "")

        'Else
        '    ErrorProvider1.SetError(TextBox13, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox13.Clear()
        'End If
    End Sub

    Private Sub TextBox15_TextChanged(sender As Object, e As EventArgs) Handles TextBox15.TextChanged
        'If Not IsNumeric(TextBox15.Text) Then


        '    ErrorProvider1.SetError(TextBox15, "")

        'Else
        '    ErrorProvider1.SetError(TextBox15, "")
        '    Dim result1 As DialogResult = MessageBox.Show("Please enter only string:",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    TextBox15.Clear()
        'End If
    End Sub

    Private Sub TextBox14_TextChanged(sender As Object, e As EventArgs) Handles TextBox14.TextChanged
        '        If IsNumeric(TextBox14.Text) Then
        '            ErrorProvider1.SetError(TextBox14, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox14, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox14.Clear()
        '        End If
    End Sub

    Private Sub TextBox16_TextChanged(sender As Object, e As EventArgs) Handles TextBox16.TextChanged
        '        If IsNumeric(TextBox16.Text) Then
        '            ErrorProvider1.SetError(TextBox16, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox16, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox16.Clear()
        '        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub TextBox17_TextChanged(sender As Object, e As EventArgs) Handles TextBox17.TextChanged
        '        If IsNumeric(TextBox17.Text) Then
        '            ErrorProvider1.SetError(TextBox17, "")
        '        Else
        '            ErrorProvider1.SetError(TextBox17, "Please Enter A Number")
        '            Dim result1 As DialogResult = MessageBox.Show("Enter a valid Mobile Number",
        '"Important Message", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            TextBox17.Clear()
        '        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 123456789
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show(" Please Enter Valid ID Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox6_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox6.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Mobile Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox10_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox10.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Pincode Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox7_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox7.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Mobile Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox8_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox8.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Integer Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox11_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox11.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox14_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox14.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowednos As String = "1234567890"
            Dim allowedsymbols As String = "%"
            If Not allowednos.Contains(e.KeyChar.ToString.ToLower) And Not allowedsymbols.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please Enter Valid Integer Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox16_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox16.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then

            Dim allowednos As String = "1234567890"
            Dim allowedsymbols As String = "%"
            If Not allowednos.Contains(e.KeyChar.ToString.ToLower) And Not allowedsymbols.Contains(e.KeyChar.ToString.ToLower) Then
                MessageBox.Show("Please Enter Valid Integer Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox17_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox17.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 123456789
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show(" Please Enter Valid ID Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox9_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox9.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox12_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox12.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox13_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox13.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub TextBox15_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox15.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub
End Class