﻿Imports System.Data.SqlClient

Public Class Events
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub DisplayEvents()
        Con.Open()
        Dim query = "select * from EventsTbl"
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        EventDGV.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub reset()

        ENameTb.Text = ""
        EDurationTb.Text = ""
        EDateDtp.ResetText()
        EAddressTb.Text = ""
        StSearchTb.Text = ""
    End Sub
    Private Sub btnAttReset_Click(sender As Object, e As EventArgs) Handles btnEReset.Click
        reset()
    End Sub

    Private Sub TeachersPicture_Click(sender As Object, e As EventArgs) Handles TeachersPicture.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub TeachersLabel_Click(sender As Object, e As EventArgs) Handles TeachersLabel.Click
        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub GunaCirclePictureBox1_Click(sender As Object, e As EventArgs) Handles GunaCirclePictureBox1.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsLabel_Click(sender As Object, e As EventArgs) Handles StudentsLabel.Click
        Dim Obj = New Departments()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesPicture_Click(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click(sender As Object, e As EventArgs) Handles FeesLabel.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardPicture_Click(sender As Object, e As EventArgs) Handles DashboardPicture.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardLabel_Click(sender As Object, e As EventArgs) Handles DashboardLabel.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Events_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayEvents()
    End Sub

    Private Sub btnESave_Click(sender As Object, e As EventArgs) Handles btnESave.Click
        If ENameTb.Text = "" Or EDurationTb.Text = "" Or EAddressTb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "insert into EventsTbl values('" & ENameTb.Text & "','" & EDateDtp.Value.Date & "','" & EDurationTb.Text & "','" & EAddressTb.Text & "')"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student saved Successfully")
                Con.Close()
                DisplayEvents()
                reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnEUpdate_Click(sender As Object, e As EventArgs) Handles btnEUpdate.Click
        If ENameTb.Text = "" Or EDurationTb.Text = "" Or EAddressTb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "update EventsTbl set EDesc='" & ENameTb.Text & "',EDate='" & EDateDtp.Value.Date & "',EDuration='" & EDurationTb.Text & "',EAddress='" & EAddressTb.Text & "' where EId=" & key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student updated Successfully")
                Con.Close()
                DisplayEvents()
                reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnEDelete_Click(sender As Object, e As EventArgs) Handles btnEDelete.Click
        If key = 0 Then
            MsgBox("Please Select the Student to Delete")
        Else
            Try
                Con.Open()
                Dim query = "delete from EventsTbl where EId=" & key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Student Deleted Successfully")
                Con.Close()
                DisplayEvents()
                reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub
    Dim Key = 0
    Private Sub EventDGV_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles EventDGV.CellMouseClick
        Dim row As DataGridViewRow = EventDGV.Rows(e.RowIndex)
        ENameTb.Text = row.Cells(1).Value.ToString
        EDateDtp.Text = row.Cells(2).Value.ToString
        EDurationTb.Text = row.Cells(3).Value.ToString
        EAddressTb.Text = row.Cells(4).Value.ToString

        If ENameTb.Text = "" Then
            Key = 0
        Else
            Key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub ENameTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ENameTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub EAddressTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles EAddressTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub EDurationTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles EDurationTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 123456789
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show(" Please Enter Valid Number")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub ENameTb_KeyDown(sender As Object, e As KeyEventArgs) Handles ENameTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub EDateDtp_KeyDown(sender As Object, e As KeyEventArgs) Handles EDateDtp.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub EDurationTb_KeyDown(sender As Object, e As KeyEventArgs) Handles EDurationTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub EAddressTb_KeyDown(sender As Object, e As KeyEventArgs) Handles EAddressTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub btnReload_Click(sender As Object, e As EventArgs) Handles btnReload.Click
        DisplayEvents()
    End Sub

    Private Sub StbtnSearch_Click(sender As Object, e As EventArgs) Handles StbtnSearch.Click
        Dim cmd As New SqlCommand("select * from EventsTbl where EId='" & StSearchTb.Text & "'", Con)

        Dim sda As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        sda.Fill(dt)
        EventDGV.DataSource = dt
    End Sub

    Private Sub LogoutPicture_Click(sender As Object, e As EventArgs) Handles LogoutPicture.Click
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub
End Class