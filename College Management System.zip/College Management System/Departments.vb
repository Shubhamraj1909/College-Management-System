﻿Imports System.Data.SqlClient
Public Class Departments
    Dim Con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Vb.Net Programs\College Management System\College Management System\CMS.mdf;Integrated Security=True")
    Private Sub DisplayDepartments()
        Con.Open()
        Dim query = "select * from DepartmentsTbl"
        Dim adapter As SqlDataAdapter
        Dim cmd = New SqlCommand(query, Con)
        adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        DepartmentsDGV.DataSource = ds.Tables(0)
        Con.Close()
    End Sub
    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles DashboardPicture.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub

    Private Sub Departments_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If DepartmentsTb.Text = "" Or DescriptionTb.Text = "" Or DurationTb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "update DepartmentsTbl set DeptName='" & DepartmentsTb.Text & "',DeptDesc='" & DescriptionTb.Text & "',DeptDuration=" & DurationTb.Text & " where DeptId=" & Key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Deparment updated Successfully")
                Con.Close()
                DisplayDepartments()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles TeachersPicture.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If DepartmentsTb.Text = "" Or DescriptionTb.Text = "" Or DurationTb.Text = "" Then
            MsgBox("Missing Information .... !")
        Else
            Try
                Con.Open()
                Dim query = "insert into DepartmentsTbl values('" & DepartmentsTb.Text & "','" & DescriptionTb.Text & "'," & DurationTb.Text & ")"
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Deparment saved Successfully")
                Con.Close()
                DisplayDepartments()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub Departments_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayDepartments()
    End Sub
    Private Sub Reset()
        DepartmentsTb.Text = ""
        DescriptionTb.Text = ""
        DurationTb.Text = ""
    End Sub
    Dim Key = 0
    Private Sub DepartmentsDGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DepartmentsDGV.CellContentClick, DepartmentsDGV.CellContentClick
        Dim row As DataGridViewRow = DepartmentsDGV.Rows(e.RowIndex)
        DepartmentsTb.Text = row.Cells(1).Value.ToString
        DescriptionTb.Text = row.Cells(2).Value.ToString
        DurationTb.Text = row.Cells(3).Value.ToString
        If DepartmentsTb.Text = "" Then
            Key = 0
        Else
            Key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Key = 0 Then
            MsgBox("Please Select the Department to Delete")
        Else
            Try
                Con.Open()
                Dim query = "delete from DepartmentsTbl where DeptId=" & Key & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Con)
                cmd.ExecuteNonQuery()
                MsgBox("Deparment Deleted Successfully")
                Con.Close()
                DisplayDepartments()
                Reset()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub TeachersLabel_Click(sender As Object, e As EventArgs) Handles TeachersLabel.Click
        Dim Obj = New Teachers()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub LogoutPicture_Click(sender As Object, e As EventArgs) Handles LogoutPicture.Click
        Dim Obj = New Login()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsPicture_Click(sender As Object, e As EventArgs) Handles StudentsPicture.Click

        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub StudentsLabel_Click(sender As Object, e As EventArgs) Handles StudentsLabel.Click

        Dim Obj = New Students()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesPicture_Click(sender As Object, e As EventArgs) Handles FeesPicture.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub FeesLabel_Click(sender As Object, e As EventArgs) Handles FeesLabel.Click
        Dim Obj = New Fees()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DashboardLabel_Click(sender As Object, e As EventArgs) Handles DashboardLabel.Click
        Dim Obj = New Dashboard()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub DurationTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles DurationTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = 1234567890
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid Integer Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub DepartmentsTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles DepartmentsTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub DescriptionTb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles DescriptionTb.KeyPress
        If Not (Asc(e.KeyChar) = 8) Then
            Dim allowednos As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
            If Not allowednos.Contains(e.KeyChar.ToString) Then
                MessageBox.Show("Enter Valid String Value")
                e.KeyChar = ChrW(0)
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub DepartmentsTb_KeyDown(sender As Object, e As KeyEventArgs) Handles DepartmentsTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub DescriptionTb_KeyDown(sender As Object, e As KeyEventArgs) Handles DescriptionTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub DurationTb_KeyDown(sender As Object, e As KeyEventArgs) Handles DurationTb.KeyDown
        If (e.KeyCode = Keys.Enter) Then

            SendKeys.Send("{Tab}")
        Else
            Exit Sub
        End If

        e.SuppressKeyPress = True
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Dim Obj = New Attendace()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        Dim Obj = New Events()
        Obj.Show()
        Me.Hide()
    End Sub
End Class